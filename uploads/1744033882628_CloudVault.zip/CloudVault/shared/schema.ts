import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Storage interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Folder operations
  getFolders(userId: number, parentId?: number): Promise<Folder[]>;
  getFolderById(id: number): Promise<Folder | undefined>;
  createFolder(folder: InsertFolder): Promise<Folder>;
  deleteFolder(id: number): Promise<boolean>;
  
  // File operations
  getFiles(userId: number, folderId?: number): Promise<File[]>;
  getFileById(id: number): Promise<File | undefined>;
  getFilesByIds(ids: number[]): Promise<File[]>;
  createFile(file: InsertFile): Promise<File>;
  updateFile(id: number, updates: Partial<File>): Promise<File | undefined>;
  deleteFile(id: number): Promise<boolean>;
  
  // File operations by special condition
  getStarredFiles(userId: number): Promise<File[]>;
  getRecentFiles(userId: number, limit?: number): Promise<File[]>;
  getTrashFiles(userId: number): Promise<File[]>;
  restoreFile(id: number): Promise<File | undefined>;
  emptyTrash(userId: number): Promise<boolean>;
  
  // Shared files operations
  shareFile(sharedFile: InsertSharedFile): Promise<SharedFile>;
  getSharedFileByToken(token: string): Promise<SharedFile | undefined>;
  getFilesSharedWithUser(userId: number): Promise<File[]>;
  getFilesSharedByUser(userId: number): Promise<{file: File, shared: SharedFile}[]>;
  
  // Storage usage
  getUserStorageUsage(userId: number): Promise<{ used: number, total: number }>;
  getUserStorageByType(userId: number): Promise<{ type: string, size: number }[]>;
  getUserStorageByFolder(userId: number): Promise<{ folderId: number | null, folderName: string, size: number }[]>;
}

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const folders = pgTable("folders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  userId: integer("user_id").notNull(),
  parentId: integer("parent_id"),
  path: text("path").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(),
  userId: integer("user_id").notNull(),
  folderId: integer("folder_id"),
  path: text("path").notNull(),
  isStarred: boolean("is_starred").notNull().default(false),
  isDeleted: boolean("is_deleted").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const sharedFiles = pgTable("shared_files", {
  id: serial("id").primaryKey(),
  fileId: integer("file_id").notNull(),
  userId: integer("user_id").notNull(),
  sharedWithUserId: integer("shared_with_user_id"),
  sharedWithEmail: text("shared_with_email"),
  accessLevel: text("access_level").notNull(),
  shareToken: text("share_token").notNull().unique(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertFolderSchema = createInsertSchema(folders).pick({
  name: true,
  userId: true,
  parentId: true,
  path: true,
});

export const insertFileSchema = createInsertSchema(files).pick({
  name: true,
  originalName: true,
  mimeType: true,
  size: true,
  userId: true,
  folderId: true,
  path: true,
});

export const insertSharedFileSchema = createInsertSchema(sharedFiles).pick({
  fileId: true,
  userId: true,
  sharedWithUserId: true,
  sharedWithEmail: true,
  accessLevel: true,
  shareToken: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertFolder = z.infer<typeof insertFolderSchema>;
export type Folder = typeof folders.$inferSelect;

export type InsertFile = z.infer<typeof insertFileSchema>;
export type File = typeof files.$inferSelect;

export type InsertSharedFile = z.infer<typeof insertSharedFileSchema>;
export type SharedFile = typeof sharedFiles.$inferSelect;

// Extended schemas for frontend validation
export const fileUploadSchema = z.object({
  file: z.instanceof(File),
  folderId: z.number().optional(),
});

export const createFolderSchema = z.object({
  name: z.string().min(1, "Folder name is required"),
  parentId: z.number().optional(),
});

export const shareFileSchema = z.object({
  fileId: z.number(),
  email: z.string().email("Invalid email address"),
  accessLevel: z.enum(["view", "edit", "comment"]),
});
