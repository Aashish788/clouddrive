import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { File, Folder } from "@shared/schema";

interface FileContextType {
  currentFolder: number | null;
  setCurrentFolder: (folderId: number | null) => void;
  view: "grid" | "list";
  setView: (view: "grid" | "list") => void;
  uploading: {
    id: string;
    fileName: string;
    progress: number;
    size: number;
    loaded: number;
  }[];
  addUploadingFile: (file: { id: string; fileName: string; size: number }) => void;
  updateUploadProgress: (id: string, loaded: number) => void;
  removeUploadingFile: (id: string) => void;
  storageUsage: { used: number; total: number };
  uploadsVisible: boolean;
  setUploadsVisible: (visible: boolean) => void;
}

const FileContext = createContext<FileContextType | undefined>(undefined);

export const FileProvider = ({ children }: { children: ReactNode }) => {
  const [currentFolder, setCurrentFolder] = useState<number | null>(null);
  const [view, setView] = useState<"grid" | "list">("grid");
  const [uploading, setUploading] = useState<
    { id: string; fileName: string; progress: number; size: number; loaded: number }[]
  >([]);
  const [uploadsVisible, setUploadsVisible] = useState(false);
  const [storageUsage, setStorageUsage] = useState<{ used: number; total: number }>({
    used: 0,
    total: 15 * 1024 * 1024 * 1024, // 15GB
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch storage usage data
  const { data: storageData } = useQuery({
    queryKey: ["/api/storage"],
    onSuccess: (data) => {
      setStorageUsage(data);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to fetch storage usage",
        variant: "destructive",
      });
    },
  });

  // Update storage usage when it changes
  useEffect(() => {
    if (storageData) {
      setStorageUsage(storageData);
    }
  }, [storageData]);

  // Show uploads area when uploading files
  useEffect(() => {
    if (uploading.length > 0 && !uploadsVisible) {
      setUploadsVisible(true);
    }
  }, [uploading, uploadsVisible]);

  const addUploadingFile = (file: { id: string; fileName: string; size: number }) => {
    setUploading((prev) => [
      ...prev,
      { ...file, progress: 0, loaded: 0 },
    ]);
  };

  const updateUploadProgress = (id: string, loaded: number) => {
    setUploading((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const progress = Math.round((loaded / item.size) * 100);
          return { ...item, progress, loaded };
        }
        return item;
      })
    );
  };

  const removeUploadingFile = (id: string) => {
    setUploading((prev) => prev.filter((item) => item.id !== id));
    
    // Hide uploads area if no more uploads
    if (uploading.length === 1) {
      setTimeout(() => {
        setUploadsVisible(false);
      }, 1000);
    }
  };

  return (
    <FileContext.Provider
      value={{
        currentFolder,
        setCurrentFolder,
        view,
        setView,
        uploading,
        addUploadingFile,
        updateUploadProgress,
        removeUploadingFile,
        storageUsage,
        uploadsVisible,
        setUploadsVisible
      }}
    >
      {children}
    </FileContext.Provider>
  );
};

export const useFileContext = () => {
  const context = useContext(FileContext);
  if (context === undefined) {
    throw new Error("useFileContext must be used within a FileProvider");
  }
  return context;
};
