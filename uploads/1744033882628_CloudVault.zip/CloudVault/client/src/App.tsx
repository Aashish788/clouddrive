import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { FileProvider } from "@/context/FileContext";

// Pages
import Dashboard from "@/pages/Dashboard";
import Recent from "@/pages/Recent";
import Shared from "@/pages/Shared";
import Starred from "@/pages/Starred";
import Trash from "@/pages/Trash";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/recent" component={Recent} />
      <Route path="/shared" component={Shared} />
      <Route path="/starred" component={Starred} />
      <Route path="/trash" component={Trash} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <FileProvider>
        <Router />
        <Toaster />
      </FileProvider>
    </QueryClientProvider>
  );
}

export default App;
