import { useState, useEffect } from "react";
import { Folder, FolderPlus, Upload } from "lucide-react";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import FileGrid from "@/components/FileGrid";
import UploadArea from "@/components/UploadArea";
import UploadProgress from "@/components/UploadProgress";
import ViewToggle from "@/components/ViewToggle";
import NewFolderModal from "@/components/NewFolderModal";
import FolderBreadcrumb from "@/components/FolderBreadcrumb";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useFileContext } from "@/context/FileContext";
import { ScrollArea } from "@/components/ui/scroll-area";

const Dashboard = () => {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [showNewFolderModal, setShowNewFolderModal] = useState(false);
  const [location] = useLocation();
  const { uploadsVisible, setCurrentFolder } = useFileContext();

  // Extract folder ID from URL and set it in the FileContext
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const folderId = params.get('folder');
      
      if (folderId) {
        const folderIdNum = parseInt(folderId, 10);
        if (!isNaN(folderIdNum)) {
          setCurrentFolder(folderIdNum);
        } else {
          // If folder ID is not a valid number, reset to root
          setCurrentFolder(null);
        }
      } else {
        setCurrentFolder(null); // Reset to root if no folder ID
      }
    } catch (error) {
      console.error("Error parsing folder ID:", error);
      setCurrentFolder(null); // Reset to root on error
    }
  }, [location, setCurrentFolder]);
  
  const toggleMobileSidebar = () => {
    setMobileSidebarOpen(!mobileSidebarOpen);
  };
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile Sidebar */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div 
            className="fixed inset-0 bg-black bg-opacity-50"
            onClick={toggleMobileSidebar}
          />
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white">
            <Sidebar />
          </div>
        </div>
      )}
      
      {/* Desktop Sidebar */}
      <Sidebar />
      
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <Header onMobileMenuToggle={toggleMobileSidebar} />
        
        <ScrollArea className="flex-1">
          <div className="py-8 px-4 sm:px-8">
            {/* Action Bar */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 space-y-4 sm:space-y-0">
              <div>
                <h1 className="text-2xl font-bold text-neutral-900">My Drive</h1>
                <p className="mt-1 text-sm text-neutral-600">Securely store, share, and collaborate on files and folders</p>
                
                {/* Folder Navigation */}
                <FolderBreadcrumb />
              </div>
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  className="flex items-center"
                  onClick={() => setShowNewFolderModal(true)}
                >
                  <FolderPlus className="w-5 h-5 mr-2 text-neutral-500" />
                  New Folder
                </Button>
                <label htmlFor="fileInput" className="cursor-pointer">
                  <Button className="flex items-center">
                    <Upload className="w-5 h-5 mr-2" />
                    Upload
                  </Button>
                  <input
                    type="file"
                    id="fileInput"
                    className="hidden"
                    multiple
                    onChange={(e) => {
                      if (e.target.files && e.target.files.length > 0) {
                        const files = Array.from(e.target.files);
                        
                        // Use the file input directly with the file objects
                        const uploadInput = document.querySelector('input[type="file"]');
                        if (uploadInput) {
                          // Just use the files directly with the upload mutation
                          // The upload mutation will be triggered by the file input's onChange event
                        }
                      }
                    }}
                  />
                </label>
              </div>
            </div>
            
            <UploadArea />
            
            {uploadsVisible && <UploadProgress />}
            
            <ViewToggle title="Recent Files" />
            
            <FileGrid />
          </div>
        </ScrollArea>
      </div>
      
      <NewFolderModal
        isOpen={showNewFolderModal}
        onClose={() => setShowNewFolderModal(false)}
      />
    </div>
  );
};

export default Dashboard;
