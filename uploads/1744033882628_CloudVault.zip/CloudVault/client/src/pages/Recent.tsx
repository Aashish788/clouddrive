import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import FileItem from "@/components/FileItem";
import ViewToggle from "@/components/ViewToggle";
import { useFileContext } from "@/context/FileContext";
import { File } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";

const Recent = () => {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const { view } = useFileContext();
  const { toast } = useToast();
  
  // Fetch recent files
  const { data: recentFiles, isLoading } = useQuery<File[]>({
    queryKey: ["/api/files/recent"],
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to load recent files",
        variant: "destructive",
      });
    },
  });
  
  const toggleMobileSidebar = () => {
    setMobileSidebarOpen(!mobileSidebarOpen);
  };
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile Sidebar */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div 
            className="fixed inset-0 bg-black bg-opacity-50"
            onClick={toggleMobileSidebar}
          />
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white">
            <Sidebar />
          </div>
        </div>
      )}
      
      {/* Desktop Sidebar */}
      <Sidebar />
      
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <Header onMobileMenuToggle={toggleMobileSidebar} />
        
        <ScrollArea className="flex-1">
          <div className="py-8 px-4 sm:px-8">
            <div className="mb-8">
              <h1 className="text-2xl font-bold text-neutral-900">Recent Files</h1>
              <p className="mt-1 text-sm text-neutral-600">Files you've recently accessed or modified</p>
            </div>
            
            <ViewToggle title="Recent Files" />
            
            {isLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-card p-4 h-32 animate-pulse">
                    <div className="w-8 h-8 bg-neutral-200 rounded-md mb-3"></div>
                    <div className="h-4 bg-neutral-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-neutral-100 rounded w-1/2"></div>
                  </div>
                ))}
              </div>
            ) : recentFiles?.length ? (
              <div 
                className={view === "grid" 
                  ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" 
                  : "flex flex-col space-y-2"
                }
              >
                {recentFiles.map((file) => (
                  <FileItem key={file.id} file={file} view={view} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <svg className="mx-auto h-12 w-12 text-neutral-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="mt-2 text-sm font-medium text-neutral-900">No recent files</h3>
                <p className="mt-1 text-sm text-neutral-500">Files you access will appear here.</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
};

export default Recent;
