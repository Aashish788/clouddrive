import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import FileItem from "@/components/FileItem";
import ViewToggle from "@/components/ViewToggle";
import { useFileContext } from "@/context/FileContext";
import { File } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { apiRequest } from "@/lib/queryClient";

const Trash = () => {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [showEmptyTrashDialog, setShowEmptyTrashDialog] = useState(false);
  const { view } = useFileContext();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch trash files
  const { data: trashFiles, isLoading } = useQuery<File[]>({
    queryKey: ["/api/files/trash"],
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to load trash files",
        variant: "destructive",
      });
    },
  });
  
  // Empty trash mutation
  const emptyTrashMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('DELETE', '/api/files/trash');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files/trash'] });
      queryClient.invalidateQueries({ queryKey: ['/api/storage'] });
      toast({
        title: "Trash emptied",
        description: "All files in trash have been permanently deleted.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to empty trash",
        variant: "destructive",
      });
    }
  });
  
  // Restore file mutation
  const restoreFileMutation = useMutation({
    mutationFn: async (fileId: number) => {
      return await apiRequest('POST', `/api/files/${fileId}/restore`);
    },
    onSuccess: (_, fileId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/files/trash'] });
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      toast({
        title: "File restored",
        description: "The file has been restored from trash.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to restore file",
        variant: "destructive",
      });
    }
  });
  
  const toggleMobileSidebar = () => {
    setMobileSidebarOpen(!mobileSidebarOpen);
  };
  
  const handleEmptyTrash = () => {
    emptyTrashMutation.mutate();
    setShowEmptyTrashDialog(false);
  };
  
  const handleRestoreFile = (fileId: number) => {
    restoreFileMutation.mutate(fileId);
  };
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile Sidebar */}
      {mobileSidebarOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div 
            className="fixed inset-0 bg-black bg-opacity-50"
            onClick={toggleMobileSidebar}
          />
          <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white">
            <Sidebar />
          </div>
        </div>
      )}
      
      {/* Desktop Sidebar */}
      <Sidebar />
      
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <Header onMobileMenuToggle={toggleMobileSidebar} />
        
        <ScrollArea className="flex-1">
          <div className="py-8 px-4 sm:px-8">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h1 className="text-2xl font-bold text-neutral-900">Trash</h1>
                <p className="mt-1 text-sm text-neutral-600">
                  Files in trash will be automatically deleted after 30 days
                </p>
              </div>
              {trashFiles?.length ? (
                <Button 
                  variant="outline" 
                  className="text-red-500 hover:text-red-600 hover:bg-red-50"
                  onClick={() => setShowEmptyTrashDialog(true)}
                >
                  Empty Trash
                </Button>
              ) : null}
            </div>
            
            <ViewToggle title="Trash" />
            
            {isLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-card p-4 h-32 animate-pulse">
                    <div className="w-8 h-8 bg-neutral-200 rounded-md mb-3"></div>
                    <div className="h-4 bg-neutral-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-neutral-100 rounded w-1/2"></div>
                  </div>
                ))}
              </div>
            ) : trashFiles?.length ? (
              <div 
                className={view === "grid" 
                  ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" 
                  : "flex flex-col space-y-2"
                }
              >
                {trashFiles.map((file) => (
                  <div key={file.id} className="relative">
                    <FileItem file={file} view={view} />
                    <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 hover:bg-opacity-10 transition-all">
                      <Button 
                        variant="secondary" 
                        className="opacity-0 hover:opacity-100"
                        onClick={() => handleRestoreFile(file.id)}
                      >
                        Restore
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="mx-auto h-12 w-12 text-neutral-400">
                  <Trash2 className="h-12 w-12" />
                </div>
                <h3 className="mt-2 text-sm font-medium text-neutral-900">Trash is empty</h3>
                <p className="mt-1 text-sm text-neutral-500">
                  Files you delete will appear here before being permanently removed.
                </p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
      
      {/* Empty Trash Confirmation Dialog */}
      <AlertDialog open={showEmptyTrashDialog} onOpenChange={setShowEmptyTrashDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Empty Trash?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. All files in trash will be permanently deleted.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleEmptyTrash}
              className="bg-red-500 hover:bg-red-600"
            >
              Empty Trash
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Trash;
