import { GridIcon, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useFileContext } from "@/context/FileContext";

interface ViewToggleProps {
  title: string;
}

const ViewToggle = ({ title }: ViewToggleProps) => {
  const { view, setView } = useFileContext();

  return (
    <div className="flex justify-between items-center mb-6">
      <h2 className="text-lg font-medium text-neutral-900">{title}</h2>
      <div className="flex items-center space-x-2">
        <Button
          variant={view === "list" ? "secondary" : "ghost"}
          size="sm"
          onClick={() => setView("list")}
          className={view === "list" ? "text-primary-600" : "text-neutral-500 hover:text-neutral-900"}
        >
          <List className="w-5 h-5" />
        </Button>
        <Button
          variant={view === "grid" ? "secondary" : "ghost"}
          size="sm"
          onClick={() => setView("grid")}
          className={view === "grid" ? "text-primary-600" : "text-neutral-500 hover:text-neutral-900"}
        >
          <GridIcon className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
};

export default ViewToggle;
