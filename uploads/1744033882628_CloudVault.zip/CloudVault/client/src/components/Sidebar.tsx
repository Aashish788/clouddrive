import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Home, 
  Clock, 
  Star, 
  Share2, 
  Trash2,
  HardDrive
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Folder } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useFileContext } from "@/context/FileContext";
import { formatBytes } from "@/lib/utils";
import StorageUsageModal from "./StorageUsageModal";

const Sidebar = () => {
  const [location] = useLocation();
  const { setCurrentFolder } = useFileContext();
  const [showStorageModal, setShowStorageModal] = useState(false);

  const { data: folders } = useQuery<Folder[]>({
    queryKey: ["/api/folders"],
  });
  
  // Fetch storage usage data
  const { data: storageData = { used: 0, total: 1 } } = useQuery({
    queryKey: ['/api/storage'],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  return (
    <div className="hidden md:flex md:flex-shrink-0">
      <div className="flex flex-col w-64 border-r border-neutral-200">
        <div className="flex items-center justify-between h-16 px-6 border-b border-neutral-200">
          <div className="flex items-center">
            <svg className="w-8 h-8 text-primary-500" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10.5 3a7.5 7.5 0 107.5 7.5h-1.5a6 6 0 11-6-6V3z"/>
              <path d="M10.5 1.5a9 9 0 11-9 9 9 9 0 019-9zm0-1.5a10.5 10.5 0 100 21 10.5 10.5 0 000-21z"/>
            </svg>
            <span className="ml-2 text-lg font-bold">CloudVault</span>
          </div>
        </div>
        <ScrollArea className="flex-grow">
          <div className="flex flex-col px-4 py-5">
            <div className="space-y-1">
              <Link 
                href="/" 
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${location === '/' ? 'bg-primary-100 text-primary-700' : 'text-neutral-700 hover:bg-neutral-100'}`}
                onClick={() => setCurrentFolder(null)}
              >
                <Home className="w-5 h-5 mr-3 text-primary-500" />
                Home
              </Link>
              <Link href="/recent" className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${location === '/recent' ? 'bg-primary-100 text-primary-700' : 'text-neutral-700 hover:bg-neutral-100'}`}>
                <Clock className="w-5 h-5 mr-3 text-neutral-500" />
                Recent
              </Link>
              <Link href="/starred" className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${location === '/starred' ? 'bg-primary-100 text-primary-700' : 'text-neutral-700 hover:bg-neutral-100'}`}>
                <Star className="w-5 h-5 mr-3 text-neutral-500" />
                Starred
              </Link>
              <Link href="/shared" className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${location === '/shared' ? 'bg-primary-100 text-primary-700' : 'text-neutral-700 hover:bg-neutral-100'}`}>
                <Share2 className="w-5 h-5 mr-3 text-neutral-500" />
                Shared
              </Link>
              <Link href="/trash" className={`flex items-center px-3 py-2 text-sm font-medium rounded-md ${location === '/trash' ? 'bg-primary-100 text-primary-700' : 'text-neutral-700 hover:bg-neutral-100'}`}>
                <Trash2 className="w-5 h-5 mr-3 text-neutral-500" />
                Trash
              </Link>
            </div>
            
            <div className="mt-8">
              <h3 className="px-3 text-xs font-semibold tracking-wider text-neutral-500 uppercase">Folders</h3>
              <div className="mt-1 space-y-1">
                {folders?.map((folder) => (
                  <Link 
                    key={folder.id} 
                    href={`/?folder=${folder.id}`}
                    className="flex items-center justify-between px-3 py-2 text-sm font-medium text-neutral-700 rounded-md group hover:bg-neutral-100"
                    onClick={(e) => {
                      // Set current folder state immediately to avoid any race conditions
                      setCurrentFolder(folder.id);
                    }}
                  >
                    <div className="flex items-center">
                      <svg className="w-5 h-5 mr-3 text-neutral-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                      </svg>
                      {folder.name}
                    </div>
                  </Link>
                ))}
              </div>
            </div>
            
            <div className="mt-8 px-3">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-semibold tracking-wider text-neutral-500 uppercase">Storage</span>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-8 px-2"
                  onClick={() => setShowStorageModal(true)}
                >
                  <HardDrive className="w-4 h-4 mr-1" /> 
                  Details
                </Button>
              </div>
              
              {/* Storage Usage Bar */}
              <div className="space-y-2">
                <Progress 
                  value={storageData.total ? (storageData.used / storageData.total) * 100 : 0} 
                  className="h-2" 
                />
                <div className="flex justify-between items-center text-xs text-neutral-600">
                  <span>{formatBytes(storageData.used)} used</span>
                  <span>{formatBytes(storageData.total - storageData.used)} free</span>
                </div>
              </div>
            </div>
            
            {showStorageModal && (
              <StorageUsageModal onClose={() => setShowStorageModal(false)} />
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
};

export default Sidebar;
