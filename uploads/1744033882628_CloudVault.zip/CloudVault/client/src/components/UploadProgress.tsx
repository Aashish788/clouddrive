import { X } from "lucide-react";
import { useFileContext } from "@/context/FileContext";
import { Progress } from "@/components/ui/progress";
import { formatBytes } from "@/utils/fileUtils";
import { Button } from "@/components/ui/button";

const UploadProgress = () => {
  const { uploading, removeUploadingFile, uploadsVisible, setUploadsVisible } = useFileContext();

  if (!uploadsVisible || uploading.length === 0) {
    return null;
  }

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-medium text-neutral-900">Active Uploads</h2>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => setUploadsVisible(false)}
          className="text-neutral-500 hover:text-neutral-700"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      {uploading.map((item) => (
        <div key={item.id} className="bg-white rounded-lg shadow-sm p-4 mb-4 border border-neutral-200">
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center">
              <svg className="w-5 h-5 text-neutral-400 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <span className="text-neutral-900 font-medium">{item.fileName}</span>
            </div>
            <span className="text-neutral-500 text-sm">{formatBytes(item.size)}</span>
          </div>
          <Progress 
            className="w-full h-2 bg-neutral-200 rounded-full overflow-hidden" 
            value={item.progress} 
          />
          <div className="flex justify-between items-center mt-2">
            <span className="text-neutral-500 text-xs">
              {item.progress}% • {formatBytes(item.loaded)} of {formatBytes(item.size)}
            </span>
            <Button
              variant="ghost" 
              size="sm"
              className="text-neutral-500 hover:text-neutral-700 p-0 h-auto"
              onClick={() => removeUploadingFile(item.id)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default UploadProgress;
