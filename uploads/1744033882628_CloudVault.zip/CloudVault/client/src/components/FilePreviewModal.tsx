import { X, Download, Star, Maximize, Minimize } from 'lucide-react';
import { File } from '@shared/schema';
import { useState } from 'react';
import { isImageFile, isVideoFile } from '@/utils/fileUtils';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface FilePreviewModalProps {
  file: File;
  onClose: () => void;
}

const FilePreviewModal = ({ file, onClose }: FilePreviewModalProps) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const queryClient = useQueryClient();
  
  // Star/unstar mutation
  const { mutate: toggleStar } = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(
        'PATCH',
        `/api/files/${file.id}`,
        { isStarred: !file.isStarred }
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      queryClient.invalidateQueries({ queryKey: ['/api/files/starred'] });
    },
  });
  
  const handleDownload = async () => {
    window.open(`/api/files/${file.id}/download`, '_blank');
  };
  
  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };
  
  const renderPreview = () => {
    if (isImageFile(file.mimeType)) {
      return (
        <img 
          src={`/api/files/${file.id}/download`} 
          alt={file.name} 
          className="max-w-full max-h-[80vh] object-contain"
        />
      );
    } else if (isVideoFile(file.mimeType)) {
      return (
        <video 
          src={`/api/files/${file.id}/download`} 
          controls 
          className="max-w-full max-h-[80vh]"
        >
          Your browser does not support the video tag.
        </video>
      );
    } else {
      // For non-previewable files, offer download option
      return (
        <div className="flex flex-col items-center justify-center p-8">
          <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mb-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-8 h-8 text-neutral-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
          </div>
          <p className="text-center mb-4">
            Preview not available for this file type.
          </p>
          <button
            onClick={handleDownload}
            className="flex items-center px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700 transition-colors"
          >
            <Download className="w-4 h-4 mr-2" />
            Download
          </button>
        </div>
      );
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div 
        className={`bg-white rounded-lg overflow-hidden flex flex-col ${
          isFullscreen ? 'fixed inset-0' : 'max-w-4xl w-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="font-semibold text-lg truncate">{file.name}</h3>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={() => toggleStar()}
              className="p-2 hover:bg-neutral-100 rounded-full transition-colors"
            >
              <Star className={`w-5 h-5 ${file.isStarred ? 'text-yellow-400 fill-yellow-400' : 'text-neutral-500'}`} />
            </button>
            
            <button
              onClick={handleDownload}
              className="p-2 hover:bg-neutral-100 rounded-full transition-colors"
            >
              <Download className="w-5 h-5 text-neutral-500" />
            </button>
            
            <button
              onClick={toggleFullscreen}
              className="p-2 hover:bg-neutral-100 rounded-full transition-colors"
            >
              {isFullscreen ? 
                <Minimize className="w-5 h-5 text-neutral-500" /> : 
                <Maximize className="w-5 h-5 text-neutral-500" />
              }
            </button>
            
            <button
              onClick={onClose}
              className="p-2 hover:bg-neutral-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-neutral-500" />
            </button>
          </div>
        </div>
        
        {/* Content */}
        <div className="flex-1 overflow-auto p-4 flex items-center justify-center bg-neutral-50">
          {renderPreview()}
        </div>
      </div>
    </div>
  );
};

export default FilePreviewModal;