import { X, Copy, CheckCircle, Mail } from 'lucide-react';
import { useState } from 'react';
import { File } from '@shared/schema';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';

interface ShareModalProps {
  file: File;
  onClose: () => void;
}

const shareFormSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  accessLevel: z.enum(['view', 'edit'], {
    required_error: "Please select an access level",
  }),
});

type ShareFormValues = z.infer<typeof shareFormSchema>;

const ShareModal = ({ file, onClose }: ShareModalProps) => {
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<ShareFormValues>({
    resolver: zodResolver(shareFormSchema),
    defaultValues: {
      email: '',
      accessLevel: 'view',
    },
  });
  
  const shareMutation = useMutation({
    mutationFn: async (values: ShareFormValues) => {
      const response = await apiRequest(
        'POST',
        `/api/files/${file.id}/share`,
        values
      );
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/files/shared-by-me'] });
      const baseUrl = window.location.origin;
      setShareUrl(`${baseUrl}${data.shareUrl}`);
      toast({
        title: "Shared successfully",
        description: "The file has been shared",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to share",
        description: "There was a problem sharing the file",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: ShareFormValues) => {
    shareMutation.mutate(values);
  };
  
  const copyToClipboard = () => {
    if (shareUrl) {
      navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      
      toast({
        title: "Copied to clipboard",
        description: "Share link has been copied",
      });
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg overflow-hidden w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="font-semibold text-lg">Share "{file.name}"</h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-neutral-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-neutral-500" />
          </button>
        </div>
        
        {/* Content */}
        <div className="p-6">
          {!shareUrl ? (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email address</FormLabel>
                      <FormControl>
                        <div className="flex items-center space-x-2">
                          <div className="relative flex-1">
                            <Mail className="absolute left-3 top-2.5 h-5 w-5 text-neutral-400" />
                            <Input 
                              placeholder="email@example.com" 
                              className="pl-10" 
                              {...field} 
                            />
                          </div>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="accessLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Access level</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select access level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="view">Can view</SelectItem>
                          <SelectItem value="edit">Can edit</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={onClose} 
                    className="mr-2"
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={shareMutation.isPending}
                  >
                    {shareMutation.isPending ? "Sharing..." : "Share"}
                  </Button>
                </div>
              </form>
            </Form>
          ) : (
            <div className="space-y-6">
              <div>
                <h4 className="font-medium mb-2">Share link</h4>
                <div className="flex items-center">
                  <Input 
                    value={shareUrl} 
                    readOnly 
                    className="pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="ml-2"
                    onClick={copyToClipboard}
                  >
                    {copied ? 
                      <CheckCircle className="h-4 w-4 text-green-500" /> : 
                      <Copy className="h-4 w-4" />
                    }
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-end">
                <Button 
                  type="button" 
                  onClick={onClose}
                >
                  Done
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ShareModal;