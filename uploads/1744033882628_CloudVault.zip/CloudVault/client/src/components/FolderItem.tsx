import { Folder, Menu, MoreVertical } from 'lucide-react';
import { formatBytes, getTimeElapsed } from '@/utils/fileUtils';
import { useFileContext } from '@/context/FileContext';
import { Folder as FolderType } from '@shared/schema';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useLocation } from 'wouter';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface FolderItemProps {
  folder: FolderType;
  view: "grid" | "list";
}

const FolderItem = ({ folder, view }: FolderItemProps) => {
  const { setCurrentFolder } = useFileContext();
  const [_, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Delete folder mutation
  const { mutate: deleteFolder, isPending: isDeleting } = useMutation({
    mutationFn: async () => {
      try {
        await apiRequest(
          'DELETE',
          `/api/folders/${folder.id}`
        );
        return true;
      } catch (error) {
        console.error("Error deleting folder:", error);
        throw error;
      }
    },
    onSuccess: () => {
      // Invalidate the folders query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/folders'] });
      toast({
        title: "Folder deleted",
        description: `Folder "${folder.name}" has been deleted along with its contents.`,
      });
    },
    onError: (error) => {
      console.error("Error deleting folder:", error);
      toast({
        title: "Error deleting folder",
        description: "Failed to delete the folder. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const handleFolderClick = () => {
    // Set current folder immediately to avoid any race conditions
    setCurrentFolder(folder.id);
    // Update the URL with the folder ID
    setLocation(`/?folder=${folder.id}`);
  };
  
  if (view === "grid") {
    return (
      <div
        onClick={handleFolderClick}
        className="bg-white border rounded-lg p-4 cursor-pointer hover:bg-neutral-50 transition-colors flex flex-col"
      >
        <div className="flex justify-between items-start">
          <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center text-orange-500 mb-3">
            <Folder className="w-6 h-6" />
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="h-8 w-8 flex items-center justify-center rounded-full hover:bg-neutral-100">
                <MoreVertical className="h-4 w-4 text-neutral-500" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem className="cursor-pointer">Rename</DropdownMenuItem>
              <DropdownMenuItem 
                onClick={(e) => {
                  e.stopPropagation(); // Prevent folder navigation
                  deleteFolder();
                }} 
                className="cursor-pointer text-red-500"
                disabled={isDeleting}
              >
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <h3 className="font-medium text-neutral-900 truncate">{folder.name}</h3>
        <span className="text-xs text-neutral-500 mt-1">
          {getTimeElapsed(new Date(folder.createdAt))}
        </span>
      </div>
    );
  }
  
  // List view
  return (
    <div
      onClick={handleFolderClick}
      className="grid grid-cols-12 items-center py-3 px-4 cursor-pointer hover:bg-neutral-50 transition-colors"
    >
      <div className="col-span-6 flex items-center">
        <div className="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center text-orange-500 mr-3">
          <Folder className="w-5 h-5" />
        </div>
        <div>
          <h3 className="font-medium text-neutral-900">{folder.name}</h3>
          <span className="text-xs text-neutral-500">Folder</span>
        </div>
      </div>
      
      <div className="col-span-2">
        <span className="text-sm text-neutral-500">-</span>
      </div>
      
      <div className="col-span-3">
        <span className="text-sm text-neutral-500">
          {getTimeElapsed(new Date(folder.createdAt))}
        </span>
      </div>
      
      <div className="col-span-1 flex justify-end">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="h-8 w-8 flex items-center justify-center rounded-full hover:bg-neutral-100">
              <MoreVertical className="h-4 w-4 text-neutral-500" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem className="cursor-pointer">Rename</DropdownMenuItem>
            <DropdownMenuItem 
              onClick={(e) => {
                e.stopPropagation(); // Prevent folder navigation
                deleteFolder();
              }} 
              className="cursor-pointer text-red-500"
              disabled={isDeleting}
            >
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};

export default FolderItem;