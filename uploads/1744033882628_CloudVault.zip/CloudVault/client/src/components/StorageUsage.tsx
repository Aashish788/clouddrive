import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { HardDrive, FolderOpen, FileType } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { formatBytes } from '@/lib/utils';

// Custom colors for the charts
const COLORS = [
  '#3b82f6', // blue-500
  '#ef4444', // red-500
  '#f97316', // orange-500
  '#10b981', // emerald-500
  '#a855f7', // purple-500
  '#ec4899', // pink-500
  '#f59e0b', // amber-500
  '#14b8a6', // teal-500
  '#6366f1', // indigo-500
  '#64748b', // slate-500
];

const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, name }: any) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * Math.PI / 180);
  const y = cy + radius * Math.sin(-midAngle * Math.PI / 180);

  return (
    <text 
      x={x} 
      y={y} 
      fill="white" 
      textAnchor={x > cx ? 'start' : 'end'} 
      dominantBaseline="central"
      fontSize="12"
      fontWeight="500"
    >
      {percent > 0.05 ? `${(percent * 100).toFixed(0)}%` : ''}
    </text>
  );
};

export default function StorageUsage() {
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch basic storage usage data
  const { data: storageData = { used: 0, total: 1 }, isLoading: isLoadingStorage } = useQuery({
    queryKey: ['/api/storage'],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Fetch storage usage by file type
  const { data: storageByType = [], isLoading: isLoadingTypeData } = useQuery({
    queryKey: ['/api/storage/by-type'],
    staleTime: 1000 * 60 * 5, // 5 minutes
    enabled: activeTab === 'by-type', // Only fetch when the tab is active
  });

  // Fetch storage usage by folder
  const { data: storageByFolder = [], isLoading: isLoadingFolderData } = useQuery({
    queryKey: ['/api/storage/by-folder'],
    staleTime: 1000 * 60 * 5, // 5 minutes
    enabled: activeTab === 'by-folder', // Only fetch when the tab is active
  });

  // Calculate percentage used
  const percentageUsed = storageData.total ? Math.min(100, (storageData.used / storageData.total) * 100) : 0;
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <HardDrive className="h-5 w-5" />
          Storage
        </CardTitle>
        <CardDescription>
          {formatBytes(storageData.used)} of {formatBytes(storageData.total)} used
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Progress value={percentageUsed} className="h-2 mb-6" />
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="by-type">By Type</TabsTrigger>
            <TabsTrigger value="by-folder">By Folder</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="h-[200px] mt-4 flex items-center justify-center">
              <div className="text-center">
                <p className="text-2xl font-bold">{percentageUsed.toFixed(1)}%</p>
                <p className="text-muted-foreground">Storage Used</p>
                <p className="mt-2">
                  {formatBytes(storageData.total - storageData.used)} available
                </p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="by-type">
            {isLoadingTypeData ? (
              <div className="h-[200px] flex items-center justify-center">
                <p>Loading...</p>
              </div>
            ) : storageByType.length === 0 ? (
              <div className="h-[200px] flex items-center justify-center">
                <div className="text-center">
                  <FileType className="h-12 w-12 mx-auto text-muted-foreground" />
                  <p className="mt-2 text-muted-foreground">No files found</p>
                </div>
              </div>
            ) : (
              <div className="h-[200px] mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={storageByType}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={renderCustomizedLabel}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="size"
                      nameKey="type"
                    >
                      {storageByType.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number) => formatBytes(value)}
                      labelFormatter={(label) => label}
                    />
                    <Legend 
                      formatter={(value, entry, index) => (
                        <span className="text-sm">{value}</span>
                      )}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="by-folder">
            {isLoadingFolderData ? (
              <div className="h-[200px] flex items-center justify-center">
                <p>Loading...</p>
              </div>
            ) : storageByFolder.length === 0 ? (
              <div className="h-[200px] flex items-center justify-center">
                <div className="text-center">
                  <FolderOpen className="h-12 w-12 mx-auto text-muted-foreground" />
                  <p className="mt-2 text-muted-foreground">No folders found</p>
                </div>
              </div>
            ) : (
              <div className="h-[200px] mt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={storageByFolder}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={renderCustomizedLabel}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="size"
                      nameKey="folderName"
                    >
                      {storageByFolder.map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number) => formatBytes(value)}
                      labelFormatter={(label) => label}
                    />
                    <Legend 
                      formatter={(value, entry, index) => (
                        <span className="text-sm">{value}</span>
                      )} 
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}