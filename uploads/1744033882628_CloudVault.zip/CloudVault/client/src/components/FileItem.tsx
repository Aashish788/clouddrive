import { useState } from 'react';
import { 
  FileText, Image, Music, Video, 
  Download, Share, Star, Trash, MoreVertical
} from 'lucide-react';
import { File } from '@shared/schema';
import { formatBytes, getTimeElapsed, getFileIcon, isPreviewable } from '@/utils/fileUtils';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import FilePreviewModal from './FilePreviewModal';
import ShareModal from './ShareModal';

interface FileItemProps {
  file: File;
  view: "grid" | "list";
}

const FileItem = ({ file, view }: FileItemProps) => {
  const [showPreview, setShowPreview] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Star/unstar mutation
  const { mutate: toggleStar } = useMutation({
    mutationFn: async () => {
      const response = await apiRequest(
        'PATCH',
        `/api/files/${file.id}`,
        { isStarred: !file.isStarred }
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      queryClient.invalidateQueries({ queryKey: ['/api/files/starred'] });
    },
  });
  
  // Delete mutation (move to trash)
  const { mutate: deleteFile, isPending: isDeleting } = useMutation({
    mutationFn: async () => {
      try {
        await apiRequest(
          'DELETE',
          `/api/files/${file.id}`
        );
        return true;
      } catch (error) {
        console.error("Error deleting file:", error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      queryClient.invalidateQueries({ queryKey: ['/api/files/trash'] });
      queryClient.invalidateQueries({ queryKey: ['/api/storage'] });
      toast({
        title: "File deleted",
        description: "The file has been moved to trash",
      });
    },
    onError: (error) => {
      console.error("Error deleting file:", error);
      toast({
        title: "Error deleting file",
        description: "Failed to delete the file. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const handleDownload = async () => {
    window.open(`/api/files/${file.id}/download`, '_blank');
  };
  
  const handlePreview = () => {
    if (isPreviewable(file.mimeType)) {
      setShowPreview(true);
    } else {
      handleDownload();
    }
  };
  
  const getFileTypeIcon = () => {
    if (file.mimeType.startsWith('image/')) {
      return <Image className="w-6 h-6" />;
    } else if (file.mimeType.startsWith('video/')) {
      return <Video className="w-6 h-6" />;
    } else if (file.mimeType.startsWith('audio/')) {
      return <Music className="w-6 h-6" />;
    }
    return <FileText className="w-6 h-6" />;
  };
  
  const getFileTypeColor = () => {
    if (file.mimeType.startsWith('image/')) {
      return 'bg-blue-50 text-blue-500';
    } else if (file.mimeType.startsWith('video/')) {
      return 'bg-purple-50 text-purple-500';
    } else if (file.mimeType.startsWith('audio/')) {
      return 'bg-pink-50 text-pink-500';
    }
    return 'bg-green-50 text-green-500';
  };
  
  if (view === "grid") {
    return (
      <>
        <div className="bg-white border rounded-lg p-4 cursor-pointer hover:bg-neutral-50 transition-colors flex flex-col">
          <div className="flex justify-between items-start">
            <div 
              className={`w-12 h-12 rounded-lg flex items-center justify-center mb-3 ${getFileTypeColor()}`}
              onClick={handlePreview}
            >
              {getFileTypeIcon()}
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button 
                  className="h-8 w-8 flex items-center justify-center rounded-full hover:bg-neutral-100"
                  onClick={(e) => e.stopPropagation()}
                >
                  <MoreVertical className="h-4 w-4 text-neutral-500" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleDownload} className="cursor-pointer">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => setShowShareModal(true)} 
                  className="cursor-pointer"
                >
                  <Share className="w-4 h-4 mr-2" />
                  Share
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => toggleStar()} 
                  className="cursor-pointer"
                >
                  <Star className={`w-4 h-4 mr-2 ${file.isStarred ? 'text-yellow-400 fill-yellow-400' : ''}`} />
                  {file.isStarred ? 'Unstar' : 'Star'}
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => deleteFile()} 
                  className="cursor-pointer text-red-500"
                >
                  <Trash className="w-4 h-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          <div onClick={handlePreview}>
            <h3 className="font-medium text-neutral-900 truncate">{file.name}</h3>
            <div className="flex justify-between items-center mt-1">
              <span className="text-xs text-neutral-500">{formatBytes(file.size)}</span>
              <span className="text-xs text-neutral-500">{getTimeElapsed(new Date(file.createdAt))}</span>
            </div>
          </div>
        </div>
        
        {showPreview && (
          <FilePreviewModal file={file} onClose={() => setShowPreview(false)} />
        )}
        
        {showShareModal && (
          <ShareModal file={file} onClose={() => setShowShareModal(false)} />
        )}
      </>
    );
  }
  
  // List view
  return (
    <>
      <div className="grid grid-cols-12 items-center py-3 px-4 cursor-pointer hover:bg-neutral-50 transition-colors">
        <div className="col-span-6 flex items-center" onClick={handlePreview}>
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-3 ${getFileTypeColor()}`}>
            {getFileTypeIcon()}
          </div>
          <div>
            <h3 className="font-medium text-neutral-900 truncate">{file.name}</h3>
            <span className="text-xs text-neutral-500">{file.mimeType}</span>
          </div>
        </div>
        
        <div className="col-span-2">
          <span className="text-sm text-neutral-500">{formatBytes(file.size)}</span>
        </div>
        
        <div className="col-span-3">
          <span className="text-sm text-neutral-500">
            {getTimeElapsed(new Date(file.createdAt))}
          </span>
        </div>
        
        <div className="col-span-1 flex justify-end">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button 
                className="h-8 w-8 flex items-center justify-center rounded-full hover:bg-neutral-100"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreVertical className="h-4 w-4 text-neutral-500" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleDownload} className="cursor-pointer">
                <Download className="w-4 h-4 mr-2" />
                Download
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => setShowShareModal(true)} 
                className="cursor-pointer"
              >
                <Share className="w-4 h-4 mr-2" />
                Share
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => toggleStar()} 
                className="cursor-pointer"
              >
                <Star className={`w-4 h-4 mr-2 ${file.isStarred ? 'text-yellow-400 fill-yellow-400' : ''}`} />
                {file.isStarred ? 'Unstar' : 'Star'}
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => deleteFile()} 
                className="cursor-pointer text-red-500"
              >
                <Trash className="w-4 h-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      {showPreview && (
        <FilePreviewModal file={file} onClose={() => setShowPreview(false)} />
      )}
      
      {showShareModal && (
        <ShareModal file={file} onClose={() => setShowShareModal(false)} />
      )}
    </>
  );
};

export default FileItem;