import { useState, useEffect } from 'react';
import { ChevronRight, Home } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { useFileContext } from '@/context/FileContext';
import { Folder } from '@shared/schema';

const FolderBreadcrumb = () => {
  const { currentFolder, setCurrentFolder } = useFileContext();
  const [breadcrumbs, setBreadcrumbs] = useState<Folder[]>([]);

  // Fetch current folder details
  const { data: folderData } = useQuery<Folder>({
    queryKey: ['/api/folders', currentFolder],
    enabled: !!currentFolder,
  });

  // Build breadcrumb trail
  useEffect(() => {
    const fetchBreadcrumbs = async () => {
      if (!currentFolder) {
        setBreadcrumbs([]);
        return;
      }

      if (folderData) {
        const trail: Folder[] = [];
        let currentFolderData = folderData;
        trail.unshift(currentFolderData);

        // Recursively fetch parent folders
        while (currentFolderData.parentId) {
          const { data: parentFolder } = await fetch(`/api/folders/${currentFolderData.parentId}`)
            .then(res => res.json());
          
          if (parentFolder) {
            trail.unshift(parentFolder);
            currentFolderData = parentFolder;
          } else {
            break;
          }
        }

        setBreadcrumbs(trail);
      }
    };

    fetchBreadcrumbs();
  }, [currentFolder, folderData]);

  // If not in any folder, don't show breadcrumbs
  if (!currentFolder) {
    return null;
  }

  return (
    <div className="flex items-center mt-2 text-sm text-neutral-500 overflow-x-auto">
      <button 
        onClick={() => setCurrentFolder(null)}
        className="flex items-center hover:text-primary-600 transition-colors"
      >
        <Home className="w-4 h-4 mr-1" />
        <span>Home</span>
      </button>

      {breadcrumbs.map((folder, index) => (
        <div key={folder.id} className="flex items-center">
          <ChevronRight className="w-4 h-4 mx-1" />
          <button
            onClick={() => setCurrentFolder(folder.id)}
            className={`hover:text-primary-600 transition-colors ${
              index === breadcrumbs.length - 1 ? 'font-medium text-neutral-900' : ''
            }`}
          >
            {folder.name}
          </button>
        </div>
      ))}
    </div>
  );
};

export default FolderBreadcrumb;