import { useState } from "react";
import { Bell, User } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface HeaderProps {
  onMobileMenuToggle: () => void;
}

const Header = ({ onMobileMenuToggle }: HeaderProps) => {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Implement search functionality when backend is ready
    toast({
      title: "Search",
      description: `Searching for "${searchQuery}"`,
    });
  };

  return (
    <>
      {/* Mobile Header */}
      <div className="flex md:hidden">
        <div className="flex items-center justify-between w-full h-16 px-4 border-b border-neutral-200 bg-white">
          <div className="flex items-center">
            <button 
              onClick={onMobileMenuToggle}
              className="p-1 mr-2 text-neutral-500 rounded-md hover:text-neutral-900 focus:outline-none focus:ring-2 focus:ring-primary-500"
            >
              <svg className="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <span className="text-lg font-bold">CloudVault</span>
          </div>
          <Button variant="ghost" size="icon" className="text-neutral-500 hover:text-neutral-900">
            <Bell className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Desktop Header */}
      <div className="flex items-center justify-between h-16 px-6 border-b border-neutral-200 bg-white">
        <div className="flex-1">
          <form onSubmit={handleSearch} className="relative max-w-md">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <svg className="w-5 h-5 text-neutral-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <Input
              type="text"
              placeholder="Search files and folders..."
              className="block w-full py-2 pl-10 pr-3 text-sm placeholder-neutral-500 bg-neutral-100 border border-transparent rounded-lg focus:outline-none focus:bg-white focus:border-primary-300 focus:ring-1 focus:ring-primary-300"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </form>
        </div>
        <div className="flex items-center space-x-4">
          <div className="hidden md:flex">
            <Button variant="ghost" size="icon" className="text-neutral-500 hover:text-neutral-900">
              <Bell className="h-5 w-5" />
            </Button>
          </div>
          <div className="relative">
            <Avatar className="h-8 w-8">
              <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" alt="User" />
              <AvatarFallback>
                <User className="h-4 w-4" />
              </AvatarFallback>
            </Avatar>
          </div>
        </div>
      </div>
    </>
  );
};

export default Header;
