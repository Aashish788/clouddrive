import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Folder, File } from '@shared/schema';
import { useFileContext } from '@/context/FileContext';
import FolderItem from './FolderItem';
import FileItem from './FileItem';

const FileGrid = () => {
  const { currentFolder, view } = useFileContext();
  const [selectedItem, setSelectedItem] = useState<File | null>(null);
  
  // Fetch folders in the current folder
  const { data: folders = [], isLoading: loadingFolders } = useQuery<Folder[]>({
    queryKey: ['/api/folders', { parentId: currentFolder }],
    queryFn: async () => {
      const parentParam = currentFolder ? `?parentId=${currentFolder}` : '';
      const response = await fetch(`/api/folders${parentParam}`);
      return response.json();
    }
  });
  
  // Fetch files in the current folder
  const { data: files = [], isLoading: loadingFiles } = useQuery<File[]>({
    queryKey: ['/api/files', { folderId: currentFolder }],
    queryFn: async () => {
      const folderParam = currentFolder ? `?folderId=${currentFolder}` : '';
      const response = await fetch(`/api/files${folderParam}`);
      return response.json();
    }
  });
  
  const isLoading = loadingFolders || loadingFiles;
  
  if (isLoading) {
    return (
      <div className="py-4">
        <div className="animate-pulse grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {[...Array(8)].map((_, index) => (
            <div key={index} className="bg-neutral-100 rounded-lg h-32"></div>
          ))}
        </div>
      </div>
    );
  }
  
  // Generate empty state message when there's no content
  if (folders.length === 0 && files.length === 0) {
    return (
      <div className="py-16 flex flex-col items-center justify-center">
        <div className="w-20 h-20 rounded-full bg-neutral-100 flex items-center justify-center mb-4">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="w-10 h-10 text-neutral-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            />
          </svg>
        </div>
        <h3 className="text-xl font-medium text-neutral-900 mb-1">No files yet</h3>
        <p className="text-neutral-500 text-center max-w-md">
          Upload files or create folders to get started. Drag and drop files here to upload.
        </p>
      </div>
    );
  }
  
  return (
    <div className="py-4">
      {view === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {folders.map((folder) => (
            <FolderItem key={folder.id} folder={folder} view="grid" />
          ))}
          
          {files.map((file) => (
            <FileItem key={file.id} file={file} view="grid" />
          ))}
        </div>
      ) : (
        <div className="border rounded-lg overflow-hidden">
          <div className="grid grid-cols-12 bg-neutral-50 border-b py-2 px-4 text-sm font-medium text-neutral-500">
            <div className="col-span-6">Name</div>
            <div className="col-span-2">Size</div>
            <div className="col-span-3">Date Modified</div>
            <div className="col-span-1"></div>
          </div>
          
          <div className="divide-y">
            {folders.map((folder) => (
              <FolderItem key={folder.id} folder={folder} view="list" />
            ))}
            
            {files.map((file) => (
              <FileItem key={file.id} file={file} view="list" />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default FileGrid;