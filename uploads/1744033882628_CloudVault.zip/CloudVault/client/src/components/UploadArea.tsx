import { useState, useRef, useEffect } from "react";
import { useDropzone } from "react-dropzone";
import { CloudUpload } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useFileContext } from "@/context/FileContext";
import { queryClient } from "@/lib/queryClient";
import { nanoid } from "nanoid";
import { Button } from "@/components/ui/button";

const UploadArea = () => {
  const { toast } = useToast();
  const { currentFolder, addUploadingFile, updateUploadProgress, removeUploadingFile, setUploadsVisible, storageUsage } = useFileContext();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Fetch storage information
  const { data: storageData } = useQuery({
    queryKey: ['/api/storage'],
    staleTime: 1000 * 60, // 1 minute
  });

  // Upload mutation
  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      console.log("Starting file upload, file:", file.name, "folder:", currentFolder);
      const formData = new FormData();
      formData.append('file', file);
      
      if (currentFolder !== null) {
        formData.append('folderId', currentFolder.toString());
        console.log("Adding folder ID to upload:", currentFolder);
      }
      
      const uploadId = nanoid();
      
      // Make sure uploads are visible when uploading starts
      setUploadsVisible(true);
      
      addUploadingFile({
        id: uploadId,
        fileName: file.name,
        size: file.size,
      });
      
      // Create XHR to track upload progress
      const xhr = new XMLHttpRequest();
      
      // Setup promise to resolve when upload completes
      return new Promise((resolve, reject) => {
        xhr.upload.addEventListener('progress', (event) => {
          if (event.lengthComputable) {
            updateUploadProgress(uploadId, event.loaded);
          }
        });
        
        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            removeUploadingFile(uploadId);
            console.log("Upload completed successfully");
            resolve(JSON.parse(xhr.response));
          } else {
            removeUploadingFile(uploadId);
            console.error("Upload failed with status", xhr.status, xhr.responseText);
            reject(new Error(`Upload failed with status ${xhr.status}: ${xhr.responseText}`));
          }
        };
        
        xhr.onerror = () => {
          removeUploadingFile(uploadId);
          console.error("Upload failed with network error");
          reject(new Error('Upload failed'));
        };
        
        xhr.open('POST', '/api/files/upload');
        xhr.send(formData);
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      queryClient.invalidateQueries({ queryKey: ['/api/storage'] });
      toast({
        title: "Upload complete",
        description: "Your file has been uploaded successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: error.message || "There was an error uploading your file.",
        variant: "destructive",
      });
    }
  });

  // Function to format bytes to human-readable format (KB, MB, GB)
  const formatSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Check if there's enough storage space for the file
  const checkStorageSpace = (fileSize: number) => {
    if (!storageData) return true; // If we don't have storage data yet, allow upload
    
    const remainingSpace = storageData.total - storageData.used;
    if (fileSize > remainingSpace) {
      toast({
        title: "Storage limit exceeded",
        description: `File size (${formatSize(fileSize)}) exceeds available space (${formatSize(remainingSpace)}). Please delete some files and try again.`,
        variant: "destructive",
      });
      return false;
    }
    return true;
  };

  const { getRootProps, getInputProps, isDragActive, open } = useDropzone({
    onDrop: (acceptedFiles) => {
      acceptedFiles.forEach(file => {
        // Check if there's enough storage space first
        if (checkStorageSpace(file.size)) {
          uploadMutation.mutate(file);
        }
      });
    },
    // This makes the dropzone not handle clicks itself
    noClick: true,
    noKeyboard: true
  });

  return (
    <div className="mb-8">
      <div 
        {...getRootProps()} 
        data-upload-area="true"
        className={`border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center transition duration-150
          ${isDragActive 
            ? 'border-primary-400 bg-primary-50' 
            : 'border-neutral-300 bg-neutral-50'
          }`}
      >
        <input {...getInputProps()} hidden />
        <CloudUpload className="w-12 h-12 text-neutral-400 mb-3" />
        <h3 className="text-neutral-900 font-medium text-lg">Drop files to upload</h3>
        <p className="text-neutral-600 text-sm mt-1 mb-4">or use the button below</p>
        
        <Button 
          onClick={open} 
          type="button"
          variant="outline"
          className="mt-2"
        >
          Select Files
        </Button>
      </div>
    </div>
  );
};

export default UploadArea;
