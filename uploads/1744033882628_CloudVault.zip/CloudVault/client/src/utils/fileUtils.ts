import { v4 as uuidv4 } from 'uuid';

/**
 * Format bytes to a human-readable string (e.g., KB, MB, GB)
 */
export const formatBytes = (bytes: number, decimals = 2): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(decimals)) + ' ' + sizes[i];
};

/**
 * Get file icon based on MIME type
 */
export const getFileIcon = (mimeType: string): string => {
  const type = mimeType.split('/')[0];
  const subtype = mimeType.split('/')[1];
  
  if (type === 'image') {
    return 'image';
  } else if (type === 'video') {
    return 'video';
  } else if (type === 'audio') {
    return 'music';
  } else if (mimeType === 'application/pdf') {
    return 'file-text';
  } else if (
    subtype === 'msword' ||
    subtype === 'vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    subtype === 'vnd.oasis.opendocument.text'
  ) {
    return 'file-text';
  } else if (
    subtype === 'vnd.ms-excel' ||
    subtype === 'vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
    subtype === 'vnd.oasis.opendocument.spreadsheet'
  ) {
    return 'file-spreadsheet';
  } else if (
    subtype === 'vnd.ms-powerpoint' ||
    subtype === 'vnd.openxmlformats-officedocument.presentationml.presentation' ||
    subtype === 'vnd.oasis.opendocument.presentation'
  ) {
    return 'file-presentation';
  } else if (
    subtype === 'zip' ||
    subtype === 'x-rar-compressed' ||
    subtype === 'x-7z-compressed' ||
    subtype === 'x-tar'
  ) {
    return 'file-archive';
  }
  
  return 'file';
};

/**
 * Extract file extension from filename
 */
export const getFileExtension = (filename: string): string => {
  return filename.split('.').pop()?.toLowerCase() || '';
};

/**
 * Generate a unique ID for file uploads
 */
export const generateUploadId = (): string => {
  return uuidv4();
};

/**
 * Get time elapsed since date in human-readable format
 */
export const getTimeElapsed = (date: Date): string => {
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffInSeconds < 60) {
    return `${diffInSeconds} second${diffInSeconds !== 1 ? 's' : ''} ago`;
  }
  
  const diffInMinutes = Math.floor(diffInSeconds / 60);
  if (diffInMinutes < 60) {
    return `${diffInMinutes} minute${diffInMinutes !== 1 ? 's' : ''} ago`;
  }
  
  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) {
    return `${diffInHours} hour${diffInHours !== 1 ? 's' : ''} ago`;
  }
  
  const diffInDays = Math.floor(diffInHours / 24);
  if (diffInDays < 30) {
    return `${diffInDays} day${diffInDays !== 1 ? 's' : ''} ago`;
  }
  
  const diffInMonths = Math.floor(diffInDays / 30);
  if (diffInMonths < 12) {
    return `${diffInMonths} month${diffInMonths !== 1 ? 's' : ''} ago`;
  }
  
  const diffInYears = Math.floor(diffInMonths / 12);
  return `${diffInYears} year${diffInYears !== 1 ? 's' : ''} ago`;
};

/**
 * Check if the file is an image based on MIME type
 */
export const isImageFile = (mimeType: string): boolean => {
  return mimeType.startsWith('image/');
};

/**
 * Check if the file is a video based on MIME type
 */
export const isVideoFile = (mimeType: string): boolean => {
  return mimeType.startsWith('video/');
};

/**
 * Check if the file is previewable (image, video, audio, PDF)
 */
export const isPreviewable = (mimeType: string): boolean => {
  return (
    isImageFile(mimeType) ||
    isVideoFile(mimeType) ||
    mimeType.startsWith('audio/') ||
    mimeType === 'application/pdf'
  );
};