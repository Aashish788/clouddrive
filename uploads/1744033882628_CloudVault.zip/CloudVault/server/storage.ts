import { 
  users, type User, type InsertUser,
  folders, type Folder, type InsertFolder,
  files, type File, type InsertFile,
  sharedFiles, type SharedFile, type InsertSharedFile,
  IStorage
} from "@shared/schema";
import path from "path";
import fs from "fs";
import { randomBytes } from "crypto";
import { db } from "./db";
import { eq, and, isNull, desc, count, sum } from "drizzle-orm";

// Create storage directories if they don't exist
const UPLOADS_DIR = path.join(process.cwd(), "uploads");
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private folders: Map<number, Folder>;
  private files: Map<number, File>;
  private sharedFiles: Map<number, SharedFile>;
  
  private currentUserId: number;
  private currentFolderId: number;
  private currentFileId: number;
  private currentSharedFileId: number;
  
  // Arbitrary storage limit per user (15GB)
  private readonly STORAGE_LIMIT = 15 * 1024 * 1024 * 1024;

  constructor() {
    this.users = new Map();
    this.folders = new Map();
    this.files = new Map();
    this.sharedFiles = new Map();
    
    this.currentUserId = 1;
    this.currentFolderId = 1;
    this.currentFileId = 1;
    this.currentSharedFileId = 1;
    
    // Create a default user
    const defaultUser: User = {
      id: this.currentUserId++,
      username: "user@example.com",
      password: "password"
    };
    this.users.set(defaultUser.id, defaultUser);
    
    // Create root folder for default user
    const rootFolder: Folder = {
      id: this.currentFolderId++,
      name: "Root",
      userId: defaultUser.id,
      parentId: null,
      path: "/",
      createdAt: new Date()
    };
    this.folders.set(rootFolder.id, rootFolder);
    
    // Create some default folders for the user
    const defaultFolders = [
      { name: "Documents", path: "/Documents" },
      { name: "Images", path: "/Images" },
      { name: "Videos", path: "/Videos" }
    ];
    
    defaultFolders.forEach(folderData => {
      const folder: Folder = {
        id: this.currentFolderId++,
        name: folderData.name,
        userId: defaultUser.id,
        parentId: rootFolder.id,
        path: folderData.path,
        createdAt: new Date()
      };
      this.folders.set(folder.id, folder);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    
    // Create root folder for new user
    const rootFolder: Folder = {
      id: this.currentFolderId++,
      name: "Root",
      userId: user.id,
      parentId: null,
      path: "/",
      createdAt: new Date()
    };
    this.folders.set(rootFolder.id, rootFolder);
    
    return user;
  }

  // Folder operations
  async getFolders(userId: number, parentId?: number): Promise<Folder[]> {
    return Array.from(this.folders.values()).filter(
      (folder) => folder.userId === userId && folder.parentId === (parentId ?? null)
    );
  }

  async getFolderById(id: number): Promise<Folder | undefined> {
    return this.folders.get(id);
  }

  async createFolder(insertFolder: InsertFolder): Promise<Folder> {
    const id = this.currentFolderId++;
    const folder: Folder = { ...insertFolder, id, createdAt: new Date() };
    this.folders.set(id, folder);
    return folder;
  }
  
  async deleteFolder(id: number): Promise<boolean> {
    const folder = this.folders.get(id);
    if (!folder) {
      return false;
    }
    
    // Delete this folder
    this.folders.delete(id);
    
    // Find all child folders and delete them recursively
    const childFolders = Array.from(this.folders.values())
      .filter(f => f.parentId === id);
    
    for (const childFolder of childFolders) {
      await this.deleteFolder(childFolder.id);
    }
    
    // Delete all files in this folder
    const folderFiles = Array.from(this.files.values())
      .filter(f => f.folderId === id);
    
    for (const file of folderFiles) {
      await this.deleteFile(file.id);
    }
    
    return true;
  }

  // File operations
  async getFiles(userId: number, folderId?: number): Promise<File[]> {
    return Array.from(this.files.values()).filter(
      (file) => 
        file.userId === userId && 
        file.folderId === (folderId ?? null) && 
        !file.isDeleted
    );
  }

  async getFileById(id: number): Promise<File | undefined> {
    return this.files.get(id);
  }

  async getFilesByIds(ids: number[]): Promise<File[]> {
    return Array.from(this.files.values()).filter(
      (file) => ids.includes(file.id) && !file.isDeleted
    );
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    const id = this.currentFileId++;
    const file: File = { 
      ...insertFile, 
      id, 
      isStarred: false, 
      isDeleted: false,
      createdAt: new Date()
    };
    this.files.set(id, file);
    return file;
  }

  async updateFile(id: number, updates: Partial<File>): Promise<File | undefined> {
    const file = this.files.get(id);
    if (!file) return undefined;
    
    const updatedFile = { ...file, ...updates };
    this.files.set(id, updatedFile);
    return updatedFile;
  }

  async deleteFile(id: number): Promise<boolean> {
    const file = this.files.get(id);
    if (!file) return false;
    
    // Soft delete by marking isDeleted
    const updatedFile = { ...file, isDeleted: true };
    this.files.set(id, updatedFile);
    return true;
  }

  // File operations by special condition
  async getStarredFiles(userId: number): Promise<File[]> {
    return Array.from(this.files.values()).filter(
      (file) => file.userId === userId && file.isStarred && !file.isDeleted
    );
  }

  async getRecentFiles(userId: number, limit: number = 10): Promise<File[]> {
    return Array.from(this.files.values())
      .filter((file) => file.userId === userId && !file.isDeleted)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async getTrashFiles(userId: number): Promise<File[]> {
    return Array.from(this.files.values()).filter(
      (file) => file.userId === userId && file.isDeleted
    );
  }

  async restoreFile(id: number): Promise<File | undefined> {
    const file = this.files.get(id);
    if (!file) return undefined;
    
    const updatedFile = { ...file, isDeleted: false };
    this.files.set(id, updatedFile);
    return updatedFile;
  }

  async emptyTrash(userId: number): Promise<boolean> {
    const trashFiles = await this.getTrashFiles(userId);
    trashFiles.forEach(file => {
      this.files.delete(file.id);
      // Also delete actual file on disk
      const filePath = path.join(UPLOADS_DIR, file.path);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    });
    return true;
  }

  // Shared files operations
  async shareFile(insertSharedFile: InsertSharedFile): Promise<SharedFile> {
    const id = this.currentSharedFileId++;
    const sharedFile: SharedFile = { ...insertSharedFile, id, createdAt: new Date() };
    this.sharedFiles.set(id, sharedFile);
    return sharedFile;
  }

  async getSharedFileByToken(token: string): Promise<SharedFile | undefined> {
    return Array.from(this.sharedFiles.values()).find(
      (shared) => shared.shareToken === token
    );
  }

  async getFilesSharedWithUser(userId: number): Promise<File[]> {
    const sharedWithUser = Array.from(this.sharedFiles.values()).filter(
      (shared) => shared.sharedWithUserId === userId
    );
    
    const fileIds = sharedWithUser.map(shared => shared.fileId);
    return this.getFilesByIds(fileIds);
  }

  async getFilesSharedByUser(userId: number): Promise<{file: File, shared: SharedFile}[]> {
    const sharedByUser = Array.from(this.sharedFiles.values()).filter(
      (shared) => shared.userId === userId
    );
    
    const result: {file: File, shared: SharedFile}[] = [];
    
    for (const shared of sharedByUser) {
      const file = await this.getFileById(shared.fileId);
      if (file && !file.isDeleted) {
        result.push({ file, shared });
      }
    }
    
    return result;
  }

  // Storage usage
  async getUserStorageUsage(userId: number): Promise<{ used: number, total: number }> {
    const userFiles = Array.from(this.files.values()).filter(
      (file) => file.userId === userId && !file.isDeleted
    );
    
    const used = userFiles.reduce((sum, file) => sum + file.size, 0);
    return { used, total: this.STORAGE_LIMIT };
  }
  
  async getUserStorageByType(userId: number): Promise<{ type: string, size: number }[]> {
    const userFiles = Array.from(this.files.values()).filter(
      (file) => file.userId === userId && !file.isDeleted
    );
    
    if (userFiles.length === 0) {
      return [];
    }
    
    // Group files by MIME type category
    const fileTypes: Record<string, number> = {};
    
    for (const file of userFiles) {
      // Get the main type from the MIME type (e.g., "image" from "image/jpeg")
      const mainType = file.mimeType.split('/')[0];
      
      // Map to more user-friendly categories
      let category: string;
      switch(mainType) {
        case 'image':
          category = 'Images';
          break;
        case 'video':
          category = 'Videos';
          break;
        case 'audio':
          category = 'Audio';
          break;
        case 'text':
          category = 'Documents';
          break;
        case 'application':
          // For PDFs and office documents
          if (file.mimeType.includes('pdf') || 
              file.mimeType.includes('document') || 
              file.mimeType.includes('spreadsheet') ||
              file.mimeType.includes('presentation')) {
            category = 'Documents';
          } else {
            category = 'Applications';
          }
          break;
        default:
          category = 'Other';
      }
      
      // Add file size to the appropriate category
      if (fileTypes[category]) {
        fileTypes[category] += file.size;
      } else {
        fileTypes[category] = file.size;
      }
    }
    
    // Convert the object to the array format required by the interface
    return Object.entries(fileTypes).map(([type, size]) => ({ type, size }));
  }
  
  async getUserStorageByFolder(userId: number): Promise<{ folderId: number | null, folderName: string, size: number }[]> {
    const userFiles = Array.from(this.files.values()).filter(
      (file) => file.userId === userId && !file.isDeleted
    );
    
    if (userFiles.length === 0) {
      return [];
    }
    
    // Group files by folder
    const folderSizes: Record<string, { folderId: number | null, size: number }> = {};
    
    for (const file of userFiles) {
      const folderId = file.folderId;
      let folderName = 'Root';
      
      if (folderId) {
        const folder = this.folders.get(folderId);
        if (folder) {
          folderName = folder.name;
        } else {
          folderName = 'Unknown';
        }
      }
      
      if (folderSizes[folderName]) {
        folderSizes[folderName].size += file.size;
      } else {
        folderSizes[folderName] = { folderId, size: file.size };
      }
    }
    
    // Convert the object to the array format required by the interface
    return Object.entries(folderSizes).map(([folderName, data]) => ({
      folderId: data.folderId,
      folderName,
      size: data.size
    }));
  }
}

export class DatabaseStorage implements IStorage {
  // Arbitrary storage limit per user (15GB)
  private readonly STORAGE_LIMIT = 15 * 1024 * 1024 * 1024;

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    
    // Create root folder for new user
    await db.insert(folders).values({
      name: "Root",
      userId: user.id,
      parentId: null,
      path: "/"
    });
    
    return user;
  }

  async getFolders(userId: number, parentId?: number): Promise<Folder[]> {
    if (parentId !== undefined) {
      return db
        .select()
        .from(folders)
        .where(and(
          eq(folders.userId, userId),
          eq(folders.parentId, parentId)
        ));
    } else {
      return db
        .select()
        .from(folders)
        .where(and(
          eq(folders.userId, userId),
          isNull(folders.parentId)
        ));
    }
  }

  async getFolderById(id: number): Promise<Folder | undefined> {
    const [folder] = await db
      .select()
      .from(folders)
      .where(eq(folders.id, id));
    return folder || undefined;
  }

  async createFolder(insertFolder: InsertFolder): Promise<Folder> {
    const [folder] = await db
      .insert(folders)
      .values(insertFolder)
      .returning();
    return folder;
  }
  
  async deleteFolder(id: number): Promise<boolean> {
    // First, get all files in this folder and mark them as deleted
    await db
      .update(files)
      .set({ isDeleted: true })
      .where(eq(files.folderId, id));
    
    // Then delete the folder (we could also implement soft delete for folders if needed)
    const [deletedFolder] = await db
      .delete(folders)
      .where(eq(folders.id, id))
      .returning();
    
    return !!deletedFolder;
  }

  async getFiles(userId: number, folderId?: number): Promise<File[]> {
    if (folderId !== undefined) {
      return db
        .select()
        .from(files)
        .where(and(
          eq(files.userId, userId),
          eq(files.folderId, folderId),
          eq(files.isDeleted, false)
        ));
    } else {
      return db
        .select()
        .from(files)
        .where(and(
          eq(files.userId, userId),
          isNull(files.folderId),
          eq(files.isDeleted, false)
        ));
    }
  }

  async getFileById(id: number): Promise<File | undefined> {
    const [file] = await db
      .select()
      .from(files)
      .where(eq(files.id, id));
    return file || undefined;
  }

  async getFilesByIds(ids: number[]): Promise<File[]> {
    if (ids.length === 0) return [];
    return db
      .select()
      .from(files)
      .where(and(
        eq(files.isDeleted, false),
        // Use in operator once drizzle-orm supports it better
        // in(files.id, ids)
      ))
      .then(allFiles => allFiles.filter(file => ids.includes(file.id)));
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    const [file] = await db
      .insert(files)
      .values({
        ...insertFile,
        isStarred: false,
        isDeleted: false
      })
      .returning();
    return file;
  }

  async updateFile(id: number, updates: Partial<File>): Promise<File | undefined> {
    const [updatedFile] = await db
      .update(files)
      .set(updates)
      .where(eq(files.id, id))
      .returning();
    return updatedFile || undefined;
  }

  async deleteFile(id: number): Promise<boolean> {
    // Soft delete by setting isDeleted to true
    const [updatedFile] = await db
      .update(files)
      .set({ isDeleted: true })
      .where(eq(files.id, id))
      .returning();
    return !!updatedFile;
  }

  async getStarredFiles(userId: number): Promise<File[]> {
    return db
      .select()
      .from(files)
      .where(and(
        eq(files.userId, userId),
        eq(files.isStarred, true),
        eq(files.isDeleted, false)
      ));
  }

  async getRecentFiles(userId: number, limit: number = 10): Promise<File[]> {
    return db
      .select()
      .from(files)
      .where(and(
        eq(files.userId, userId),
        eq(files.isDeleted, false)
      ))
      .orderBy(desc(files.createdAt))
      .limit(limit);
  }

  async getTrashFiles(userId: number): Promise<File[]> {
    return db
      .select()
      .from(files)
      .where(and(
        eq(files.userId, userId),
        eq(files.isDeleted, true)
      ));
  }

  async restoreFile(id: number): Promise<File | undefined> {
    const [restoredFile] = await db
      .update(files)
      .set({ isDeleted: false })
      .where(eq(files.id, id))
      .returning();
    return restoredFile || undefined;
  }

  async emptyTrash(userId: number): Promise<boolean> {
    // Get all trashed files first so we can delete them from disk
    const trashFiles = await this.getTrashFiles(userId);
    
    // Delete files from the database
    await db.delete(files).where(
      and(
        eq(files.userId, userId),
        eq(files.isDeleted, true)
      )
    );
    
    // Delete files from disk
    trashFiles.forEach(file => {
      const filePath = path.join(UPLOADS_DIR, file.path);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    });
    
    return true;
  }

  async shareFile(insertSharedFile: InsertSharedFile): Promise<SharedFile> {
    const [sharedFile] = await db
      .insert(sharedFiles)
      .values(insertSharedFile)
      .returning();
    return sharedFile;
  }

  async getSharedFileByToken(token: string): Promise<SharedFile | undefined> {
    const [sharedFile] = await db
      .select()
      .from(sharedFiles)
      .where(eq(sharedFiles.shareToken, token));
    return sharedFile || undefined;
  }

  async getFilesSharedWithUser(userId: number): Promise<File[]> {
    const shared = await db
      .select()
      .from(sharedFiles)
      .where(eq(sharedFiles.sharedWithUserId, userId));
    
    if (shared.length === 0) return [];
    
    const fileIds = shared.map(s => s.fileId);
    return this.getFilesByIds(fileIds);
  }

  async getFilesSharedByUser(userId: number): Promise<{file: File, shared: SharedFile}[]> {
    const shared = await db
      .select()
      .from(sharedFiles)
      .where(eq(sharedFiles.userId, userId));
      
    const result: {file: File, shared: SharedFile}[] = [];
    
    for (const sharedItem of shared) {
      const file = await this.getFileById(sharedItem.fileId);
      if (file && !file.isDeleted) {
        result.push({ file, shared: sharedItem });
      }
    }
    
    return result;
  }

  async getUserStorageUsage(userId: number): Promise<{ used: number, total: number }> {
    const result = await db
      .select({ totalSize: sum(files.size) })
      .from(files)
      .where(and(
        eq(files.userId, userId),
        eq(files.isDeleted, false)
      ));
    
    const used = result[0]?.totalSize || 0;
    return { used, total: this.STORAGE_LIMIT };
  }
  
  async getUserStorageByType(userId: number): Promise<{ type: string, size: number }[]> {
    // Get all active (not deleted) files for this user
    const userFiles = await db
      .select()
      .from(files)
      .where(and(
        eq(files.userId, userId),
        eq(files.isDeleted, false)
      ));
    
    // If no files, return empty array
    if (userFiles.length === 0) {
      return [];
    }
    
    // Group files by MIME type category
    const fileTypes: Record<string, number> = {};
    
    for (const file of userFiles) {
      // Get the main type from the MIME type (e.g., "image" from "image/jpeg")
      const mainType = file.mimeType.split('/')[0];
      
      // Map to more user-friendly categories
      let category: string;
      switch(mainType) {
        case 'image':
          category = 'Images';
          break;
        case 'video':
          category = 'Videos';
          break;
        case 'audio':
          category = 'Audio';
          break;
        case 'text':
          category = 'Documents';
          break;
        case 'application':
          // For PDFs and office documents
          if (file.mimeType.includes('pdf') || 
              file.mimeType.includes('document') || 
              file.mimeType.includes('spreadsheet') ||
              file.mimeType.includes('presentation')) {
            category = 'Documents';
          } else {
            category = 'Applications';
          }
          break;
        default:
          category = 'Other';
      }
      
      // Add file size to the appropriate category
      if (fileTypes[category]) {
        fileTypes[category] += file.size;
      } else {
        fileTypes[category] = file.size;
      }
    }
    
    // Convert the object to the array format required by the interface
    return Object.entries(fileTypes).map(([type, size]) => ({ type, size }));
  }
  
  async getUserStorageByFolder(userId: number): Promise<{ folderId: number | null, folderName: string, size: number }[]> {
    // Get all active (not deleted) files for this user
    const userFiles = await db
      .select()
      .from(files)
      .where(and(
        eq(files.userId, userId),
        eq(files.isDeleted, false)
      ));
    
    // Get all folders for this user
    const userFolders = await db
      .select()
      .from(folders)
      .where(eq(folders.userId, userId));
    
    // Create a map of folder IDs to folder names for quick lookup
    const folderMap = new Map<number, string>();
    for (const folder of userFolders) {
      folderMap.set(folder.id, folder.name);
    }
    
    // Group files by folder
    const folderSizes: Record<string, { folderId: number | null, size: number }> = {};
    
    for (const file of userFiles) {
      const folderId = file.folderId;
      // Use folder name if available, or "Root" for null
      const folderName = folderId ? folderMap.get(folderId) || 'Unknown' : 'Root';
      
      if (folderSizes[folderName]) {
        folderSizes[folderName].size += file.size;
      } else {
        folderSizes[folderName] = { folderId, size: file.size };
      }
    }
    
    // Convert the object to the array format required by the interface
    return Object.entries(folderSizes).map(([folderName, data]) => ({
      folderId: data.folderId,
      folderName,
      size: data.size
    }));
  }
}

// Switch from MemStorage to DatabaseStorage
export const storage = new DatabaseStorage();
