import { pool } from './db';
import { IStorage, User, InsertUser, Folder, InsertFolder, File, InsertFile, SharedFile, InsertSharedFile } from '@shared/schema';
import { v4 as uuidv4 } from 'uuid';

export class PgStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await pool.query(
      'SELECT * FROM users WHERE id = $1',
      [id]
    );
    return result.rows[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await pool.query(
      'SELECT * FROM users WHERE username = $1',
      [username]
    );
    return result.rows[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await pool.query(
      'INSERT INTO users (username, email, password) VALUES ($1, $2, $3) RETURNING *',
      [user.username, user.email, user.password]
    );
    return result.rows[0];
  }

  // Folder operations
  async getFolders(userId: number, parentId?: number): Promise<Folder[]> {
    const params = [userId];
    let query = 'SELECT * FROM folders WHERE user_id = $1';
    
    if (parentId === null) {
      query += ' AND parent_id IS NULL';
    } else if (parentId !== undefined) {
      query += ' AND parent_id = $2';
      params.push(parentId);
    }
    
    const result = await pool.query(query, params);
    
    return result.rows.map(row => ({
      id: row.id,
      name: row.name,
      userId: row.user_id,
      parentId: row.parent_id,
      createdAt: row.created_at
    }));
  }

  async getFolderById(id: number): Promise<Folder | undefined> {
    const result = await pool.query(
      'SELECT * FROM folders WHERE id = $1',
      [id]
    );
    
    if (result.rows.length === 0) return undefined;
    
    const row = result.rows[0];
    return {
      id: row.id,
      name: row.name,
      userId: row.user_id,
      parentId: row.parent_id,
      createdAt: row.created_at
    };
  }

  async createFolder(folder: InsertFolder): Promise<Folder> {
    const result = await pool.query(
      'INSERT INTO folders (name, user_id, parent_id) VALUES ($1, $2, $3) RETURNING *',
      [folder.name, folder.userId, folder.parentId]
    );
    
    const row = result.rows[0];
    return {
      id: row.id,
      name: row.name,
      userId: row.user_id,
      parentId: row.parent_id,
      createdAt: row.created_at
    };
  }

  // File operations
  async getFiles(userId: number, folderId?: number): Promise<File[]> {
    const params = [userId];
    let query = 'SELECT * FROM files WHERE user_id = $1 AND is_trashed = FALSE';
    
    if (folderId === null) {
      query += ' AND folder_id IS NULL';
    } else if (folderId !== undefined) {
      query += ' AND folder_id = $2';
      params.push(folderId);
    }
    
    const result = await pool.query(query, params);
    
    return result.rows.map(row => ({
      id: row.id,
      name: row.name,
      mimeType: row.mime_type,
      size: row.size,
      path: row.path,
      folderId: row.folder_id,
      userId: row.user_id,
      isStarred: row.is_starred,
      isTrashed: row.is_trashed,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    }));
  }

  async getFileById(id: number): Promise<File | undefined> {
    const result = await pool.query(
      'SELECT * FROM files WHERE id = $1',
      [id]
    );
    
    if (result.rows.length === 0) return undefined;
    
    const row = result.rows[0];
    return {
      id: row.id,
      name: row.name,
      mimeType: row.mime_type,
      size: row.size,
      path: row.path,
      folderId: row.folder_id,
      userId: row.user_id,
      isStarred: row.is_starred,
      isTrashed: row.is_trashed,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }

  async getFilesByIds(ids: number[]): Promise<File[]> {
    if (ids.length === 0) return [];
    
    const paramPlaceholders = ids.map((_, i) => `$${i + 1}`).join(',');
    const query = `SELECT * FROM files WHERE id IN (${paramPlaceholders})`;
    
    const result = await pool.query(query, ids);
    
    return result.rows.map(row => ({
      id: row.id,
      name: row.name,
      mimeType: row.mime_type,
      size: row.size,
      path: row.path,
      folderId: row.folder_id,
      userId: row.user_id,
      isStarred: row.is_starred,
      isTrashed: row.is_trashed,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    }));
  }

  async createFile(file: InsertFile): Promise<File> {
    const result = await pool.query(
      `INSERT INTO files 
       (name, mime_type, size, path, folder_id, user_id, is_starred, is_trashed) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
       RETURNING *`,
      [
        file.name, 
        file.mimeType, 
        file.size, 
        file.path, 
        file.folderId, 
        file.userId, 
        file.isStarred || false, 
        file.isTrashed || false
      ]
    );
    
    const row = result.rows[0];
    return {
      id: row.id,
      name: row.name,
      mimeType: row.mime_type,
      size: row.size,
      path: row.path,
      folderId: row.folder_id,
      userId: row.user_id,
      isStarred: row.is_starred,
      isTrashed: row.is_trashed,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }

  async updateFile(id: number, updates: Partial<File>): Promise<File | undefined> {
    // Create update query dynamically based on provided fields
    const updateFields: string[] = [];
    const values: any[] = [];
    let paramCounter = 1;

    if (updates.name !== undefined) {
      updateFields.push(`name = $${paramCounter++}`);
      values.push(updates.name);
    }
    if (updates.mimeType !== undefined) {
      updateFields.push(`mime_type = $${paramCounter++}`);
      values.push(updates.mimeType);
    }
    if (updates.size !== undefined) {
      updateFields.push(`size = $${paramCounter++}`);
      values.push(updates.size);
    }
    if (updates.path !== undefined) {
      updateFields.push(`path = $${paramCounter++}`);
      values.push(updates.path);
    }
    if (updates.folderId !== undefined) {
      updateFields.push(`folder_id = $${paramCounter++}`);
      values.push(updates.folderId);
    }
    if (updates.isStarred !== undefined) {
      updateFields.push(`is_starred = $${paramCounter++}`);
      values.push(updates.isStarred);
    }
    if (updates.isTrashed !== undefined) {
      updateFields.push(`is_trashed = $${paramCounter++}`);
      values.push(updates.isTrashed);
    }

    updateFields.push(`updated_at = NOW()`);

    if (updateFields.length === 0) {
      return this.getFileById(id);
    }

    // Add the ID as the last parameter
    values.push(id);

    const result = await pool.query(
      `UPDATE files SET ${updateFields.join(', ')} WHERE id = $${paramCounter} RETURNING *`,
      values
    );

    if (result.rows.length === 0) {
      return undefined;
    }

    const row = result.rows[0];
    return {
      id: row.id,
      name: row.name,
      mimeType: row.mime_type,
      size: row.size,
      path: row.path,
      folderId: row.folder_id,
      userId: row.user_id,
      isStarred: row.is_starred,
      isTrashed: row.is_trashed,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  }

  async deleteFile(id: number): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM files WHERE id = $1 RETURNING id',
      [id]
    );
    return result.rows.length > 0;
  }

  // File operations by special condition
  async getStarredFiles(userId: number): Promise<File[]> {
    const result = await pool.query(
      'SELECT * FROM files WHERE user_id = $1 AND is_starred = TRUE AND is_trashed = FALSE',
      [userId]
    );
    
    return result.rows.map(row => ({
      id: row.id,
      name: row.name,
      mimeType: row.mime_type,
      size: row.size,
      path: row.path,
      folderId: row.folder_id,
      userId: row.user_id,
      isStarred: row.is_starred,
      isTrashed: row.is_trashed,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    }));
  }

  async getRecentFiles(userId: number, limit: number = 10): Promise<File[]> {
    const result = await pool.query(
      'SELECT * FROM files WHERE user_id = $1 AND is_trashed = FALSE ORDER BY updated_at DESC LIMIT $2',
      [userId, limit]
    );
    
    return result.rows.map(row => ({
      id: row.id,
      name: row.name,
      mimeType: row.mime_type,
      size: row.size,
      path: row.path,
      folderId: row.folder_id,
      userId: row.user_id,
      isStarred: row.is_starred,
      isTrashed: row.is_trashed,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    }));
  }

  async getTrashFiles(userId: number): Promise<File[]> {
    const result = await pool.query(
      'SELECT * FROM files WHERE user_id = $1 AND is_trashed = TRUE',
      [userId]
    );
    
    return result.rows.map(row => ({
      id: row.id,
      name: row.name,
      mimeType: row.mime_type,
      size: row.size,
      path: row.path,
      folderId: row.folder_id,
      userId: row.user_id,
      isStarred: row.is_starred,
      isTrashed: row.is_trashed,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    }));
  }

  async restoreFile(id: number): Promise<File | undefined> {
    return this.updateFile(id, { isTrashed: false });
  }

  async emptyTrash(userId: number): Promise<boolean> {
    const result = await pool.query(
      'DELETE FROM files WHERE user_id = $1 AND is_trashed = TRUE RETURNING id',
      [userId]
    );
    return result.rows.length > 0;
  }

  // Shared files operations
  async shareFile(sharedFile: InsertSharedFile): Promise<SharedFile> {
    const token = sharedFile.token || uuidv4();

    const result = await pool.query(
      'INSERT INTO shared_files (file_id, user_id, shared_with, token) VALUES ($1, $2, $3, $4) RETURNING *',
      [sharedFile.fileId, sharedFile.userId, sharedFile.sharedWith, token]
    );
    
    const row = result.rows[0];
    return {
      id: row.id,
      fileId: row.file_id,
      userId: row.user_id,
      sharedWith: row.shared_with,
      token: row.token,
      createdAt: row.created_at
    };
  }

  async getSharedFileByToken(token: string): Promise<SharedFile | undefined> {
    const result = await pool.query(
      'SELECT * FROM shared_files WHERE token = $1',
      [token]
    );
    
    if (result.rows.length === 0) return undefined;
    
    const row = result.rows[0];
    return {
      id: row.id,
      fileId: row.file_id,
      userId: row.user_id,
      sharedWith: row.shared_with,
      token: row.token,
      createdAt: row.created_at
    };
  }

  async getFilesSharedWithUser(userId: number): Promise<File[]> {
    const result = await pool.query(
      `SELECT f.* 
       FROM files f
       JOIN shared_files sf ON f.id = sf.file_id
       WHERE sf.shared_with = $1 AND f.is_trashed = FALSE`,
      [userId]
    );
    
    return result.rows.map(row => ({
      id: row.id,
      name: row.name,
      mimeType: row.mime_type,
      size: row.size,
      path: row.path,
      folderId: row.folder_id,
      userId: row.user_id,
      isStarred: row.is_starred,
      isTrashed: row.is_trashed,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    }));
  }

  async getFilesSharedByUser(userId: number): Promise<{file: File, shared: SharedFile}[]> {
    const result = await pool.query(
      `SELECT f.*, sf.id as sf_id, sf.user_id as sf_user_id, sf.shared_with, sf.token, sf.created_at as sf_created_at
       FROM files f
       JOIN shared_files sf ON f.id = sf.file_id
       WHERE sf.user_id = $1 AND f.is_trashed = FALSE`,
      [userId]
    );
    
    return result.rows.map(row => ({
      file: {
        id: row.id,
        name: row.name,
        mimeType: row.mime_type,
        size: row.size,
        path: row.path,
        folderId: row.folder_id,
        userId: row.user_id,
        isStarred: row.is_starred,
        isTrashed: row.is_trashed,
        createdAt: row.created_at,
        updatedAt: row.updated_at
      },
      shared: {
        id: row.sf_id,
        fileId: row.id,
        userId: row.sf_user_id,
        sharedWith: row.shared_with,
        token: row.token,
        createdAt: row.sf_created_at
      }
    }));
  }

  // Storage usage
  async getUserStorageUsage(userId: number): Promise<{ used: number; total: number }> {
    const result = await pool.query(
      'SELECT SUM(size) as total_size FROM files WHERE user_id = $1 AND is_trashed = FALSE',
      [userId]
    );
    
    const used = parseInt(result.rows[0].total_size) || 0;
    const total = 15 * 1024 * 1024 * 1024; // 15GB
    
    return { used, total };
  }
}

export const pgStorage = new PgStorage();