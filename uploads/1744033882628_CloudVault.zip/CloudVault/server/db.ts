import pg from 'pg';
import { log } from './vite';
import { drizzle } from 'drizzle-orm/node-postgres';

const { Pool } = pg;

// Get connection details from environment variables
const {
  PGHOST,
  PGUSER,
  PGPASSWORD,
  PGDATABASE,
  PGPORT,
  DATABASE_URL
} = process.env;

// Create a connection pool
export const pool = new Pool({
  host: PGHOST,
  user: PGUSER,
  password: PGPASSWORD,
  database: PGDATABASE,
  port: PGPORT ? parseInt(PGPORT, 10) : 5432,
  // Use database URL as connection string if available
  connectionString: DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Create Drizzle ORM instance
export const db = drizzle(pool);

// Test the connection
pool.connect()
  .then(() => log('Connected to PostgreSQL database', 'database'))
  .catch(err => {
    console.error('Database connection error:', err.stack);
    process.exit(1);
  });

// Initialize tables
export async function initializeDatabase() {
  const client = await pool.connect();
  try {
    // Begin transaction
    await client.query('BEGIN');

    // Create users table
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL
      )
    `);

    // Create folders table
    await client.query(`
      CREATE TABLE IF NOT EXISTS folders (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        user_id INTEGER REFERENCES users(id),
        parent_id INTEGER REFERENCES folders(id),
        path VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create files table
    await client.query(`
      CREATE TABLE IF NOT EXISTS files (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        mime_type VARCHAR(255) NOT NULL,
        size INTEGER NOT NULL,
        path VARCHAR(255) NOT NULL,
        folder_id INTEGER REFERENCES folders(id),
        user_id INTEGER REFERENCES users(id),
        is_starred BOOLEAN DEFAULT FALSE,
        is_deleted BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create shared_files table
    await client.query(`
      CREATE TABLE IF NOT EXISTS shared_files (
        id SERIAL PRIMARY KEY,
        file_id INTEGER REFERENCES files(id),
        user_id INTEGER REFERENCES users(id),
        shared_with_user_id INTEGER REFERENCES users(id),
        shared_with_email VARCHAR(255),
        access_level VARCHAR(50) NOT NULL,
        share_token VARCHAR(255) NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create default user if it doesn't exist
    const userExists = await client.query('SELECT * FROM users WHERE username = $1', ['user@example.com']);
    if (userExists.rows.length === 0) {
      await client.query(
        'INSERT INTO users (username, password) VALUES ($1, $2) RETURNING id',
        ['user@example.com', 'password']
      );
    }

    // Get or create default user
    const userResult = await client.query('SELECT id FROM users WHERE username = $1', ['user@example.com']);
    const userId = userResult.rows[0].id;

    // Create root folder if it doesn't exist
    const rootFolderExists = await client.query(
      'SELECT * FROM folders WHERE name = $1 AND user_id = $2 AND parent_id IS NULL',
      ['Root', userId]
    );
    
    if (rootFolderExists.rows.length === 0) {
      await client.query(
        'INSERT INTO folders (name, user_id, parent_id, path) VALUES ($1, $2, $3, $4)',
        ['Root', userId, null, '/']
      );
    }

    // Commit transaction
    await client.query('COMMIT');
    log('Database initialized successfully', 'database');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Error initializing database:', err);
    throw err;
  } finally {
    client.release();
  }
}