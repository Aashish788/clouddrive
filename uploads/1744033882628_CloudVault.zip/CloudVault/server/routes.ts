import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomBytes } from "crypto";
import { 
  insertFolderSchema, 
  insertFileSchema, 
  insertSharedFileSchema,
  createFolderSchema,
  shareFileSchema
} from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import session from "express-session";

// Extend session interface to include userId
declare module "express-session" {
  interface SessionData {
    userId?: number;
  }
}

// Create uploads directory if it doesn't exist
const UPLOADS_DIR = path.join(process.cwd(), "uploads");
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Configure multer for file uploads
const storage_config = multer.diskStorage({
  destination: (req: Express.Request, file: Express.Multer.File, cb: (error: Error | null, destination: string) => void) => {
    // We'll organize files in user-specific folders
    const userId = (req.session as any).userId || 1; // Default to user 1 for now
    const userDir = path.join(UPLOADS_DIR, userId.toString());
    if (!fs.existsSync(userDir)) {
      fs.mkdirSync(userDir, { recursive: true });
    }
    cb(null, userDir);
  },
  filename: (req: Express.Request, file: Express.Multer.File, cb: (error: Error | null, filename: string) => void) => {
    // Generate a unique filename to prevent collisions
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const extension = path.extname(file.originalname);
    cb(null, uniqueSuffix + extension);
  }
});

const upload = multer({ 
  storage: storage_config,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB file size limit
  }
});

// Helper to get current user from session
const getCurrentUser = async (req: Request) => {
  // For development, use a default user
  const userId = (req.session as any).userId || 1;
  return await storage.getUser(userId);
};

export async function registerRoutes(app: Express): Promise<Server> {

  // API Routes
  // Get user storage usage
  app.get("/api/storage", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const usage = await storage.getUserStorageUsage(currentUser.id);
    res.json(usage);
  });
  
  // Get storage usage by file type
  app.get("/api/storage/by-type", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const storageByType = await storage.getUserStorageByType(currentUser.id);
    res.json(storageByType);
  });
  
  // Get storage usage by folder
  app.get("/api/storage/by-folder", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const storageByFolder = await storage.getUserStorageByFolder(currentUser.id);
    res.json(storageByFolder);
  });

  // Folder operations
  // List folders
  app.get("/api/folders", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const parentId = req.query.parentId ? parseInt(req.query.parentId as string) : undefined;
    const folders = await storage.getFolders(currentUser.id, parentId);
    res.json(folders);
  });
  
  // Get folder by ID
  app.get("/api/folders/:id", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const folderId = parseInt(req.params.id);
    const folder = await storage.getFolderById(folderId);
    
    if (!folder) {
      return res.status(404).json({ message: "Folder not found" });
    }
    
    if (folder.userId !== currentUser.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    res.json(folder);
  });

  // Create folder
  app.post("/api/folders", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const folderData = createFolderSchema.parse(req.body);
      
      // Validation passed, prepare to create folder
      const parentId = folderData.parentId || null;
      
      // Get parent folder to determine path
      let parentPath = "/";
      if (parentId) {
        const parentFolder = await storage.getFolderById(parentId);
        if (!parentFolder) {
          return res.status(404).json({ message: "Parent folder not found" });
        }
        parentPath = parentFolder.path;
      }
      
      const folderPath = path.join(parentPath, folderData.name);
      
      const newFolder = await storage.createFolder({
        name: folderData.name,
        userId: currentUser.id,
        parentId: parentId,
        path: folderPath
      });
      
      res.status(201).json(newFolder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to create folder" });
      }
    }
  });

  // Delete folder
  app.delete("/api/folders/:id", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const folderId = parseInt(req.params.id);
    const folder = await storage.getFolderById(folderId);
    
    if (!folder) {
      return res.status(404).json({ message: "Folder not found" });
    }
    
    if (folder.userId !== currentUser.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    // Don't allow deleting the root folder
    if (folder.parentId === null && folder.name === "Root") {
      return res.status(400).json({ message: "Cannot delete root folder" });
    }
    
    await storage.deleteFolder(folderId);
    res.status(204).send();
  });
  
  // File operations
  // List files
  app.get("/api/files", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const folderId = req.query.folderId ? parseInt(req.query.folderId as string) : undefined;
    const files = await storage.getFiles(currentUser.id, folderId);
    res.json(files);
  });

  // Get file by ID
  app.get("/api/files/:id", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const fileId = parseInt(req.params.id);
    const file = await storage.getFileById(fileId);
    
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }
    
    if (file.userId !== currentUser.id) {
      // Check if file is shared with this user
      const sharedFiles = await storage.getFilesSharedWithUser(currentUser.id);
      const isShared = sharedFiles.some(f => f.id === fileId);
      
      if (!isShared) {
        return res.status(403).json({ message: "Access denied" });
      }
    }
    
    res.json(file);
  });

  // Upload file
  app.post("/api/files/upload", upload.single("file"), async (req: Request & { file?: Express.Multer.File }, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    try {
      const folderId = req.body.folderId ? parseInt(req.body.folderId) : null;
      
      // Validate folder if provided
      if (folderId) {
        const folder = await storage.getFolderById(folderId);
        if (!folder || folder.userId !== currentUser.id) {
          return res.status(404).json({ message: "Folder not found" });
        }
      }
      
      // Check user storage limit
      const { used, total } = await storage.getUserStorageUsage(currentUser.id);
      if (used + req.file.size > total) {
        // Remove the uploaded file
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ message: "Storage limit exceeded" });
      }
      
      // Store file metadata
      const relativePath = path.relative(UPLOADS_DIR, req.file.path);
      
      const newFile = await storage.createFile({
        name: req.file.filename,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
        userId: currentUser.id,
        folderId: folderId,
        path: relativePath
      });
      
      res.status(201).json(newFile);
    } catch (error) {
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  // Download file
  app.get("/api/files/:id/download", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const fileId = parseInt(req.params.id);
    const file = await storage.getFileById(fileId);
    
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }
    
    if (file.userId !== currentUser.id) {
      // Check if file is shared with this user
      const sharedFiles = await storage.getFilesSharedWithUser(currentUser.id);
      const isShared = sharedFiles.some(f => f.id === fileId);
      
      if (!isShared) {
        return res.status(403).json({ message: "Access denied" });
      }
    }
    
    const filePath = path.join(UPLOADS_DIR, file.path);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File not found on disk" });
    }
    
    res.setHeader("Content-Disposition", `attachment; filename="${file.originalName}"`);
    res.setHeader("Content-Type", file.mimeType);
    
    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
  });

  // Update file (star/unstar)
  app.patch("/api/files/:id", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const fileId = parseInt(req.params.id);
    const file = await storage.getFileById(fileId);
    
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }
    
    if (file.userId !== currentUser.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    const { isStarred } = req.body;
    if (isStarred !== undefined) {
      const updatedFile = await storage.updateFile(fileId, { isStarred });
      return res.json(updatedFile);
    }
    
    res.status(400).json({ message: "No valid update fields provided" });
  });

  // Delete file (move to trash)
  app.delete("/api/files/:id", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const fileId = parseInt(req.params.id);
    const file = await storage.getFileById(fileId);
    
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }
    
    if (file.userId !== currentUser.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    await storage.deleteFile(fileId);
    res.status(204).send();
  });

  // Special file collections
  // Get starred files
  app.get("/api/files/starred", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const files = await storage.getStarredFiles(currentUser.id);
    res.json(files);
  });

  // Get recent files
  app.get("/api/files/recent", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const files = await storage.getRecentFiles(currentUser.id, limit);
    res.json(files);
  });

  // Get trash files
  app.get("/api/files/trash", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const files = await storage.getTrashFiles(currentUser.id);
    res.json(files);
  });

  // Restore file from trash
  app.post("/api/files/:id/restore", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const fileId = parseInt(req.params.id);
    const file = await storage.getFileById(fileId);
    
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }
    
    if (file.userId !== currentUser.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    const restoredFile = await storage.restoreFile(fileId);
    res.json(restoredFile);
  });

  // Empty trash
  app.delete("/api/files/trash", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    await storage.emptyTrash(currentUser.id);
    res.status(204).send();
  });

  // Sharing operations
  // Share a file
  app.post("/api/files/:id/share", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const fileId = parseInt(req.params.id);
    const file = await storage.getFileById(fileId);
    
    if (!file) {
      return res.status(404).json({ message: "File not found" });
    }
    
    if (file.userId !== currentUser.id) {
      return res.status(403).json({ message: "Access denied" });
    }
    
    try {
      const { email, accessLevel } = shareFileSchema.parse({
        fileId,
        ...req.body
      });
      
      // Check if user exists
      const targetUser = await storage.getUserByUsername(email);
      let sharedWithUserId = undefined;
      
      if (targetUser) {
        sharedWithUserId = targetUser.id;
      }
      
      // Generate a unique share token
      const shareToken = randomBytes(16).toString('hex');
      
      const sharedFile = await storage.shareFile({
        fileId,
        userId: currentUser.id,
        sharedWithUserId,
        sharedWithEmail: email,
        accessLevel,
        shareToken
      });
      
      res.status(201).json({
        ...sharedFile,
        shareUrl: `/shared/${shareToken}`
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to share file" });
      }
    }
  });

  // Get files shared with me
  app.get("/api/files/shared-with-me", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const files = await storage.getFilesSharedWithUser(currentUser.id);
    res.json(files);
  });

  // Get files I've shared
  app.get("/api/files/shared-by-me", async (req: Request, res: Response) => {
    const currentUser = await getCurrentUser(req);
    if (!currentUser) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const sharedFiles = await storage.getFilesSharedByUser(currentUser.id);
    res.json(sharedFiles);
  });

  // Access shared file by token
  app.get("/api/shared/:token", async (req: Request, res: Response) => {
    const { token } = req.params;
    
    const sharedFile = await storage.getSharedFileByToken(token);
    if (!sharedFile) {
      return res.status(404).json({ message: "Shared file not found" });
    }
    
    const file = await storage.getFileById(sharedFile.fileId);
    if (!file || file.isDeleted) {
      return res.status(404).json({ message: "File not found or deleted" });
    }
    
    res.json({ file, accessLevel: sharedFile.accessLevel });
  });

  // Download shared file by token
  app.get("/api/shared/:token/download", async (req: Request, res: Response) => {
    const { token } = req.params;
    
    const sharedFile = await storage.getSharedFileByToken(token);
    if (!sharedFile) {
      return res.status(404).json({ message: "Shared file not found" });
    }
    
    const file = await storage.getFileById(sharedFile.fileId);
    if (!file || file.isDeleted) {
      return res.status(404).json({ message: "File not found or deleted" });
    }
    
    const filePath = path.join(UPLOADS_DIR, file.path);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "File not found on disk" });
    }
    
    res.setHeader("Content-Disposition", `attachment; filename="${file.originalName}"`);
    res.setHeader("Content-Type", file.mimeType);
    
    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
  });

  const httpServer = createServer(app);
  return httpServer;
}
